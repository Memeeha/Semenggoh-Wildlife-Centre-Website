import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, doc, deleteDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js"; // Your Firebase configuration

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Track which question is being edited
let currentEditingId = null;

// Function to load and display quiz questions
async function loadQuestions() {
    try {
        const snapshot = await getDocs(collection(db, "quiz_questions"));
        const tbody = document.getElementById('questions-container').getElementsByTagName('tbody')[0];
        tbody.innerHTML = ""; // Clear existing content

        snapshot.forEach(docSnap => {
            const data = docSnap.data();
            const tr = document.createElement('tr');

            tr.innerHTML = `
                <td>${data.question}</td>
                <td>${data.options.join(', ')}</td>
                <td>${data.correctAnswer}</td>  <!-- Display the actual answer string -->
                <td>
                    <button class="ADedit-btn" data-id="${docSnap.id}">Edit</button>
                    <button class="ADdelete-btn" data-id="${docSnap.id}">Delete</button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        // Add event listeners to edit buttons
        document.querySelectorAll('.ADedit-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const id = e.target.getAttribute('data-id');
                const questionDoc = snapshot.docs.find(doc => doc.id === id);
                if (questionDoc) {
                    const questionData = questionDoc.data();
                    editQuestion(id, questionData);
                    
                    // Show the form when edit is clicked
                    const form = document.getElementById('adminquiz_form');
                    form.style.display = 'block';
                    form.classList.add('visible');
                    document.getElementById('adminquiz_form_button').textContent = 'Hide Quiz Upload Form';
                    document.getElementById('adminquiz_form_button').style.backgroundColor = '#38664a';
                }
            });
        });

        // Add event listeners to delete buttons
        document.querySelectorAll('.ADdelete-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const id = e.target.getAttribute('data-id');
                if (confirm('Are you sure you want to delete this question?')) {
                    await deleteQuestion(id);
                }
            });
        });

    } catch (error) {
        console.error("Error loading questions:", error);
        alert("Failed to load questions. Please check the console for details.");
    }
}

// Function to delete a question
async function deleteQuestion(id) {
    try {
        await deleteDoc(doc(db, "quiz_questions", id));
        alert('Question deleted successfully!');
        if (currentEditingId === id) {
            resetForm();
        }
        loadQuestions(); // Reload the questions after deletion
    } catch (error) {
        console.error("Error deleting question:", error);
        alert("Failed to delete question. Please check the console for details.");
    }
}

// Function to populate the form with question data for editing
function editQuestion(id, data) {
    currentEditingId = id;
    document.getElementById('question').value = data.question;
    document.getElementById('optionA').value = data.options[0];
    document.getElementById('optionB').value = data.options[1];
    document.getElementById('optionC').value = data.options[2];
    document.getElementById('optionD').value = data.options[3];
    document.getElementById('correct-answer').value = data.correctAnswer; // Directly set the correct answer string

    // Change the submit button text to indicate editing mode
    const submitButton = document.querySelector('#adminquiz_form_data button[type="submit"]');
    submitButton.textContent = "Update Question";
}

// Function to reset the form
function resetForm() {
    currentEditingId = null;
    document.getElementById('adminquiz_form_data').reset();
    const submitButton = document.querySelector('#adminquiz_form_data button[type="submit"]');
    submitButton.textContent = "Upload Question";
}

// Function to update a question
async function updateQuestion(id) {
    try {
        const question = document.getElementById('question').value;
        const optionA = document.getElementById('optionA').value;
        const optionB = document.getElementById('optionB').value;
        const optionC = document.getElementById('optionC').value;
        const optionD = document.getElementById('optionD').value;
        const correctAnswer = document.getElementById('correct-answer').value; // Now just the actual string answer

        // Basic validation
        if (!question || !optionA || !optionB || !optionC || !optionD) {
            alert("Please fill in all fields");
            return;
        }

        await updateDoc(doc(db, "quiz_questions", id), {
            question: question,
            options: [optionA, optionB, optionC, optionD],
            correctAnswer: correctAnswer // Store the actual answer string
        });

        alert('Question updated successfully!');
        resetForm();
        loadQuestions(); // Reload the questions after update
    } catch (error) {
        console.error("Error updating question:", error);
        alert("Failed to update question. Please check the console for details.");
    }
}

// Form submission handler
document.getElementById('adminquiz_form_data').addEventListener('submit', async (e) => {
    e.preventDefault();

    if (currentEditingId) {
        await updateQuestion(currentEditingId);
    } else {
        try {
            const question = document.getElementById('question').value;
            const optionA = document.getElementById('optionA').value;
            const optionB = document.getElementById('optionB').value;
            const optionC = document.getElementById('optionC').value;
            const optionD = document.getElementById('optionD').value;
            const correctAnswer = document.getElementById('correct-answer').value; // Actual answer string

            // Basic validation
            if (!question || !optionA || !optionB || !optionC || !optionD) {
                alert("Please fill in all fields");
                return;
            }

            await addDoc(collection(db, "quiz_questions"), {
                question: question,
                options: [optionA, optionB, optionC, optionD],
                correctAnswer: correctAnswer // Store the actual answer string
            });

            alert('Question uploaded successfully!');
            document.getElementById('adminquiz_form_data').reset();
            loadQuestions(); // Reload the questions after adding
        } catch (error) {
            console.error("Error adding question:", error);
            alert("Failed to add question. Please check the console for details.");
        }
    }
});

// Fetch and display guide performance data
async function loadGuidePerformance() {
    try {
        const snapshot = await getDocs(collection(db, "guide_performance"));
        const performanceContainer = document.getElementById('performance-table').getElementsByTagName('tbody')[0];
        performanceContainer.innerHTML = "";  // Clear existing data

        snapshot.forEach(docSnap => {
            const data = docSnap.data();
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${data.guideName}</td>
                <td>${data.status}</td>
                <td>${data.score}</td>
            `;
            performanceContainer.appendChild(tr);
        });

        // Apply styling to the performance table
        enhancePerformanceTable();
    } catch (error) {
        console.error("Error loading guide performance:", error);
    }
}

// Toggle the quiz form visibility
document.getElementById('adminquiz_form_button').addEventListener('click', function() {
    const form = document.getElementById('adminquiz_form');
    const isHidden = form.style.display === 'none' || form.style.display === '';
    
    if (isHidden) {
        form.style.display = 'block';
        form.classList.add('visible');
        this.textContent = 'Hide Quiz Upload Form';
        this.style.backgroundColor = '#38664a';
    } else {
        form.classList.remove('visible');
        form.style.display = 'none';
        this.textContent = 'Upload New Quiz Question';
        this.style.backgroundColor = '#4a7c59';
    }
});

// Apply status pill styling to the performance table
function enhancePerformanceTable() {
    const performanceTable = document.getElementById('performance-table');
    if (!performanceTable) return;
    
    const statusCells = performanceTable.querySelectorAll('tbody td:nth-child(2)');
    statusCells.forEach(cell => {
        const status = cell.textContent.trim();
        const statusClass = status.toLowerCase() === 'passed' ? 'passed' : 'failed';
        cell.innerHTML = `<span class="status-pill ${statusClass}">${status}</span>`;
    });
    
    // Enhance score cells with color coding
    const scoreCells = performanceTable.querySelectorAll('tbody td:nth-child(3)');
    scoreCells.forEach(cell => {
        const score = parseInt(cell.textContent);
        if (score >= 80) {
            cell.style.color = '#28a745'; // Green for high scores
        } else if (score >= 60) {
            cell.style.color = '#fd7e14'; // Orange for medium scores
        } else {
            cell.style.color = '#dc3545'; // Red for low scores
        }
    });
}

// Initialize everything when the page loads
window.addEventListener('DOMContentLoaded', function() {
    loadQuestions();
    loadGuidePerformance();
    
    // Add subtle entrance animation to sections
    const sections = document.querySelectorAll('.adminquiz_section');
    sections.forEach((section, index) => {
        section.style.animationDelay = `${index * 0.15}s`;
    });
});
// Add event listener to reset form when the form is hidden
document.getElementById('adminquiz_form_button').addEventListener('click', function() {
    if (this.textContent === 'Upload New Quiz Question') {
        resetForm();
    }
});