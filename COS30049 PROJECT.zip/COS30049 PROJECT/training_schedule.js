import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  getDocs,
  addDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Dummy list of courses and their details
const courses = [
  {
    name: "English Course (Online)",
    description: "Focuses on enhancing English language proficiency of park guides.",
    schedule: "Monday, 3:00 PM - 5:00 PM",
    duration: "3 hours"
  },
  {
    name: "Malay Course (Online)",
    description: "Improves Malay communication skills for cultural accessibility.",
    schedule: "Monday, 5:00 PM - 7:00 PM",
    duration: "3 hours"
  },
  {
    name: "Chinese Course (Online)",
    description: "Trains guides for Chinese-speaking tourists.",
    schedule: "Wednesday, 5:00 PM - 7:00 PM",
    duration: "3 hours"
  },
  {
    name: "Park History and Geography",
    description: "Teaches historical and geographical features of the park.",
    schedule: "Tuesday, 3:00 PM - 6:00 PM",
    duration: "3 hours"
  },
  {
    name: "Nature Walk Training",
    description: "Teaches how to lead interactive nature walks.",
    schedule: "Tuesday, 8:00 AM - 11:00 AM",
    duration: "3 hours"
  },
  {
    name: "Bird Watching Training",
    description: "Focuses on bird species identification and visitor engagement.",
    schedule: "Wednesday, 8:00 AM - 11:00 AM",
    duration: "3 hours"
  },
  
  {
    name: "Orang Utan Caregiving Training",
    description: "Focused on the care and rehabilitation of orangutans, this course teaches guides about orangutan behavior, habitat preservation, and how to safely and responsibly educate visitors about these endangered species.",
    schedule: "Wednesday, 2:00 PM - 5:00 PM",
    duration: "3 hours"
  },
  {
    name: "Wildlife Conservation and Protection",
    description: "Guides will gain an understanding of wildlife conservation practices, endangered species protection, and the role of park guides in educating visitors about the importance of preserving biodiversity.",
    schedule: "Thursday, 8:00 AM - 11:00 AM",
    duration: "3 hours"
  },
  {
    name: "Flora and Fauna Identification",
    description: "This course teaches park guides how to identify and classify different plant and animal species within the park.",
    schedule: "Monday, 8:00 AM - 11:00 AM",
    duration: "3 hours"
  },
  {
    name: "Environmental Sustainability Practices",
    description: "Guides will be trained in sustainable practices that minimize environmental impact, such as waste management, water conservation, and eco-friendly tourism practices, allowing them to advocate for and implement sustainable practices in their daily work.",
    schedule: "Thursday, 2:00 PM - 5:00 PM",
    duration: "3 hours"
  },
  {
    name: "Ecotourism Principles",
    description: "This course introduces park guides to the principles of ecotourism, emphasizing the importance of preserving natural resources while providing visitors with an educational and environmentally responsible experience.",
    schedule: "Friday, 8:00 AM - 11:00 AM",
    duration: "3 hours"
  },
  {
    name: "Visitor Engagement and Communication Skills",
    description: "Park guides will learn how to engage visitors, handle diverse groups, provide effective storytelling, and deliver information in an interactive, friendly, and engaging manner that promotes learning and enjoyment.",
    schedule: "Friday, 2:00 PM - 5:00 PM",
    duration: "3 hours"
  },
];

async function loadGuides() {
  const snapshot = await getDocs(collection(db, "park_guides"));
  const guides = [];
  snapshot.forEach(doc => {
    guides.push(doc.data().username);
  });
  return guides;
}

async function assignGuide(course, guideName, statusEl) {
  try {
    const today = new Date().toISOString().split("T")[0]; // e.g., "2025-05-15"

    await addDoc(collection(db, "guide_courses"), {
      course_name: course.name,
      username: guideName,
      training_date: today,
      description: course.description,
      training_status: "Assigned"
    });

    statusEl.textContent = `Assigned ${guideName} to ${course.name}`;
    statusEl.style.color = "green";
  } catch (err) {
    console.error(err);
    statusEl.textContent = "Assignment failed.";
    statusEl.style.color = "red";
  }
}

async function renderCourses() {
  const container = document.getElementById("courseContainer");
  const guides = await loadGuides();

  courses.forEach(course => {
    const card = document.createElement("div");
    card.className = "training-card";

    const guideOptions = guides.map(
      g => `<option value="${g}">${g}</option>`
    ).join("");

    card.innerHTML = `
      <h2>${course.name}</h2>
      <hr class="title-line" />
      <p>${course.description}</p>
      <p><strong>Schedule:</strong> ${course.schedule}</p>
      <p><strong>Duration:</strong> ${course.duration}</p>
      <div class="assign-section">
        <select>
          <option value="" disabled selected>Select a guide</option>
          ${guideOptions}
        </select>
        <button class="assign-btn">Assign Course</button>
        <p class="assigned"></p>
      </div>
    `;

    const select = card.querySelector("select");
    const button = card.querySelector(".assign-btn");
    const status = card.querySelector(".assigned");

    button.addEventListener("click", () => {
      const selectedGuide = select.value;
      if (!selectedGuide) {
        status.textContent = "Please select a guide.";
        status.style.color = "red";
        return;
      }
      assignGuide(course, selectedGuide, status);
    });

    container.appendChild(card);
  });
}

document.addEventListener("DOMContentLoaded", renderCourses);
