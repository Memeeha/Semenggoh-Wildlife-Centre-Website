// Import Firebase v9 modular SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getDatabase, ref, onValue, off } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-database.js";
import { firebaseConfig } from "./firebase-config.js";

class IoTFirebaseManager {
    constructor() {
        this.sensorConfig = {
            'Intruder Detected': {
                key: 'buttonPressed',
                unit: '',
                icon: 'fas fa-user-secret',
                format: (value) => value ? 'Yes' : 'No'
            },
            'Humidity': {
                key: 'humidity',
                unit: '%',
                icon: 'fas fa-tint',
                format: (value) => `${value}%`
            },
            'Temperature': {
                key: 'temperature',
                unit: '°C',
                icon: 'fas fa-thermometer-half',
                format: (value) => `${value}°C`
            },
            'Soil Moisture': {
                key: 'soilMoisture',
                unit: '',
                icon: 'fas fa-seedling',
                format: (value) => value
            }
        };

        this.alertThresholds = {
            humidity: { min: 30, max: 80 },
            temperature: { min: 10, max: 30 },
            soilMoisture: { min: 500, max: 750 }
        };

        this.isConnected = false;
        this.retryCount = 0;
        this.maxRetries = 3;
        this.listeners = new Map();

        this.init();
    }

    async init() {
        try {
            console.log('Initializing Firebase...');
            this.app = initializeApp(firebaseConfig);
            this.database = getDatabase(this.app, "https://test-9d9ca-default-rtdb.asia-southeast1.firebasedatabase.app");
            this.sensorsRef = ref(this.database, 'sensors');

            console.log('Firebase v9 initialized successfully');
            console.log('Database reference:', this.sensorsRef);

            this.updateConnectionStatus(true);
            this.isConnected = true;

            await this.startMonitoring();
            this.checkConnectionStatus();

        } catch (error) {
            console.error('Firebase initialization failed:', error);
            this.updateConnectionStatus(false);
            this.isConnected = false;

            if (this.retryCount < this.maxRetries) {
                this.retryCount++;
                console.log(`Retrying initialization... Attempt ${this.retryCount}/${this.maxRetries}`);
                setTimeout(() => this.init(), 2000 * this.retryCount);
            }
        }
    }

    updateConnectionStatus(connected) {
        const statusDot = document.getElementById('connectionStatusDot');
        const statusText = document.getElementById('connectionStatusText');

        if (statusDot && statusText) {
            if (connected) {
                statusDot.className = 'iot-status-dot iot-connected';
                statusText.textContent = 'Connected';
                console.log('Status updated: Connected');
            } else {
                statusDot.className = 'iot-status-dot iot-disconnected';
                statusText.textContent = 'Disconnected';
                console.log('Status updated: Disconnected');
            }
        }

        const statusIndicator = document.getElementById('iotConnectionStatus');
        if (statusIndicator) {
            const statusSpan = statusIndicator.querySelector('span');
            if (connected) {
                statusIndicator.style.background = '#27ae60';
                if (statusSpan) statusSpan.textContent = 'Connected';
            } else {
                statusIndicator.style.background = '#e74c3c';
                if (statusSpan) statusSpan.textContent = 'Disconnected';
            }
        }
    }

    async startMonitoring() {
        try {
            console.log('Starting sensor monitoring...');

            if (this.listeners.has('sensors')) {
                const oldListener = this.listeners.get('sensors');
                off(this.sensorsRef, 'value', oldListener);
            }

            const listener = onValue(this.sensorsRef, (snapshot) => {
                const data = snapshot.val();
                console.log('Firebase data received:', data);
                if (data) {
                    this.updateEnvironmentalData(data);
                    this.updateEnvironmentalAlerts(data);
                    this.updateWeatherDisplay(data);
                } else {
                    console.log('No data found at sensors path');
                    this.showNoDataMessage();
                }
            }, (error) => {
                console.error('Firebase read error:', error);
                this.updateConnectionStatus(false);
                this.isConnected = false;

                setTimeout(() => {
                    if (!this.isConnected) {
                        console.log('Attempting to reconnect...');
                        this.init();
                    }
                }, 5000);
            });

            this.listeners.set('sensors', listener);

            console.log('Sensor monitoring started successfully');

        } catch (error) {
            console.error('Error starting monitoring:', error);
            this.updateConnectionStatus(false);
        }
    }

    updateEnvironmentalData(data) {
        console.log('Updating environmental data table...');

        const dataTable = document.getElementById('iotDataTable');
        const dataBody = document.getElementById('iotDataBody');
        const loadingElement = document.getElementById('iotDataLoading');

        if (!dataTable || !dataBody) {
            console.error('Required table elements not found');
            return;
        }

        if (loadingElement) loadingElement.style.display = 'none';
        dataTable.style.display = 'table';

        dataBody.innerHTML = '';

        Object.entries(this.sensorConfig).forEach(([label, config]) => {
            const value = data[config.key];
            console.log(`Processing ${label}: ${value}`);

            const row = document.createElement('tr');
            row.className = 'iot-data-row';

            const labelCell = document.createElement('td');
            labelCell.className = 'iot-data-label';
            labelCell.innerHTML = `<i class="${config.icon}"></i> ${label}`;

            const valueCell = document.createElement('td');
            valueCell.className = 'iot-data-value';

            if (value !== undefined && value !== null) {
                valueCell.textContent = config.format(value);

                if (this.isCriticalValue(config.key, value)) {
                    valueCell.classList.add('highlight');
                }
            } else {
                valueCell.textContent = 'N/A';
                valueCell.style.color = '#95a5a6';
            }

            row.appendChild(labelCell);
            row.appendChild(valueCell);
            dataBody.appendChild(row);
        });

        console.log('Environmental data table updated successfully');
    }

    updateEnvironmentalAlerts(data) {
        console.log('Updating environmental alerts...');

        const alertsContainer = document.getElementById('iotAlertsContainer');
        const loadingElement = document.getElementById('iotAlertsLoading');

        if (!alertsContainer) {
            console.error('Alerts container not found');
            return;
        }

        if (loadingElement) loadingElement.style.display = 'none';
        alertsContainer.style.display = 'grid';

        alertsContainer.innerHTML = '';

        const alerts = this.generateAlerts(data);
        console.log('Generated alerts:', alerts);

        if (alerts.length === 0) {
            const noAlertsDiv = document.createElement('div');
            noAlertsDiv.className = 'iot-no-alerts';
            noAlertsDiv.innerHTML = `
                <i class="fas fa-check-circle"></i>
                All systems operating normally
            `;
            alertsContainer.appendChild(noAlertsDiv);
        } else {
            alerts.forEach(alert => {
                const alertCard = this.createAlertCard(alert);
                alertsContainer.appendChild(alertCard);
            });
        }

        console.log('Environmental alerts updated successfully');
    }

    updateWeatherDisplay(data) {
        console.log('Updating weather display...');

        const temperatureValue = document.getElementById('temperatureValue');
        if (temperatureValue && data.temperature !== undefined) {
            temperatureValue.textContent = `${data.temperature}°C`;
        }

        const humidityValue = document.getElementById('humidityValue');
        if (humidityValue && data.humidity !== undefined) {
            humidityValue.textContent = `${data.humidity}%`;
        }

        console.log('Weather display updated successfully');
    }

    generateAlerts(data) {
        const alerts = [];

        const humidity = data.humidity;
        if (humidity !== undefined && humidity !== null) {
            if (humidity < this.alertThresholds.humidity.min) {
                alerts.push({
                    id: 'humidity-low',
                    type: 'warning',
                    title: 'Low Humidity Alert',
                    message: `Humidity is critically low at ${humidity}% (< ${this.alertThresholds.humidity.min}%)`,
                    icon: 'fas fa-tint',
                    severity: 'high'
                });
            } else if (humidity > this.alertThresholds.humidity.max) {
                alerts.push({
                    id: 'humidity-high',
                    type: 'warning',
                    title: 'High Humidity Alert',
                    message: `Humidity is critically high at ${humidity}% (> ${this.alertThresholds.humidity.max}%)`,
                    icon: 'fas fa-tint',
                    severity: 'high'
                });
            }
        }

        const temperature = data.temperature;
        if (temperature !== undefined && temperature !== null) {
            if (temperature < this.alertThresholds.temperature.min) {
                alerts.push({
                    id: 'temperature-low',
                    type: 'critical',
                    title: 'Low Temperature Alert',
                    message: `Temperature is dangerously low at ${temperature}°C (< ${this.alertThresholds.temperature.min}°C)`,
                    icon: 'fas fa-thermometer-empty',
                    severity: 'critical'
                });
            } else if (temperature > this.alertThresholds.temperature.max) {
                alerts.push({
                    id: 'temperature-high',
                    type: 'critical',
                    title: 'High Temperature Alert',
                    message: `Temperature is dangerously high at ${temperature}°C (> ${this.alertThresholds.temperature.max}°C)`,
                    icon: 'fas fa-thermometer-full',
                    severity: 'critical'
                });
            }
        }

        const soilMoisture = data.soilMoisture;
        if (soilMoisture !== undefined && soilMoisture !== null) {
            if (soilMoisture < this.alertThresholds.soilMoisture.min) {
                alerts.push({
                    id: 'soil-wet',
                    type: 'warning',
                    title: 'Wet Soil Alert',
                    message: `Soil moisture is too high at ${soilMoisture} (< ${this.alertThresholds.soilMoisture.min})`,
                    icon: 'fas fa-seedling',
                    severity: 'medium'
                });
            } else if (soilMoisture > this.alertThresholds.soilMoisture.max) {
                alerts.push({
                    id: 'soil-dry',
                    type: 'warning',
                    title: 'Dry Soil Alert',
                    message: `Soil moisture is too low at ${soilMoisture} (> ${this.alertThresholds.soilMoisture.max})`,
                    icon: 'fas fa-seedling',
                    severity: 'medium'
                });
            }
        }

        if (data.buttonPressed === true || data.buttonPressed === 1) {
            alerts.push({
                id: 'intruder-detected',
                type: 'critical',
                title: 'Security Alert',
                message: 'Intruder detected in the monitoring area',
                icon: 'fas fa-user-secret',
                severity: 'critical'
            });
        }

        return alerts;
    }

    createAlertCard(alert) {
        const card = document.createElement('div');
        card.className = `iot-alert-card ${alert.severity === 'critical' ? 'critical' : ''}`;
        card.id = `iot-alert-${alert.id}`;

        card.innerHTML = `
            <h3 class="iot-alert-title">
                <i class="${alert.icon}"></i>
                ${alert.title}
            </h3>
            <p class="iot-alert-message">${alert.message}</p>
        `;

        return card;
    }

    isCriticalValue(key, value) {
        const thresholds = this.alertThresholds[key];
        if (!thresholds || value === null || value === undefined) return false;

        return value < thresholds.min || value > thresholds.max;
    }

    showNoDataMessage() {
        console.log('Showing no data message');

        const dataTable = document.getElementById('iotDataTable');
        const loadingElement = document.getElementById('iotDataLoading');

        if (loadingElement) {
            loadingElement.style.display = 'flex';
            loadingElement.innerHTML = `
                <div class="iot-spinner"></div>
                <span class="iot-loading-text">No sensor data available - Check ESP32 connection</span>
            `;
        }

        if (dataTable) {
            dataTable.style.display = 'none';
        }
    }

    refreshData() {
        console.log('Refreshing IoT data...');

        const loadingElement = document.getElementById('iotDataLoading');
        if (loadingElement) {
            loadingElement.style.display = 'flex';
            loadingElement.innerHTML = `
                <div class="iot-spinner"></div>
                <span class="iot-loading-text">Refreshing sensor data...</span>
            `;
        }

        if (this.isConnected) {
            this.startMonitoring();
        } else {
            this.init();
        }
    }

    updateThresholds(newThresholds) {
        Object.assign(this.alertThresholds, newThresholds);
        console.log('Alert thresholds updated:', this.alertThresholds);
    }

    checkConnectionStatus() {
        if (this.database) {
            const connectedRef = ref(this.database, '.info/connected');

            const connectionListener = onValue(connectedRef, (snapshot) => {
                const connected = snapshot.val();
                console.log('Firebase connection status:', connected);

                this.isConnected = connected;
                this.updateConnectionStatus(connected);

                if (!connected && window.dashboardUI) {
                    window.dashboardUI.showNotification(
                        'Connection Lost',
                        'Attempting to reconnect to the server...',
                        'warning'
                    );
                } else if (connected && this.retryCount > 0) {
                    this.retryCount = 0;
                }
            });

            this.listeners.set('connection', connectionListener);
        }
    }

    testWithMockData() {
        console.log('Testing with mock data...');
        const mockData = {
            temperature: 25.5,
            humidity: 65,
            soilMoisture: 600,
            buttonPressed: false
        };

        this.updateEnvironmentalData(mockData);
        this.updateEnvironmentalAlerts(mockData);
        this.updateWeatherDisplay(mockData);
    }

    destroy() {
        console.log('Cleaning up IoT Firebase Manager...');

        this.listeners.forEach((listener, key) => {
            if (key === 'sensors' && this.sensorsRef) {
                off(this.sensorsRef, 'value', listener);
            } else if (key === 'connection') {
                const connectedRef = ref(this.database, '.info/connected');
                off(connectedRef, 'value', listener);
            }
        });

        this.listeners.clear();
        this.isConnected = false;
    }
}

// Initialize IoT Firebase Manager when DOM content loads
let iotManager;

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing IoT Manager...');
    iotManager = new IoTFirebaseManager();

    window.iotManager = iotManager;

    // Initialize refresh button
    const refreshButton = document.getElementById('refreshButton');
    if (refreshButton) {
        refreshButton.addEventListener('click', function () {
            this.classList.add('iot-refreshing');
            iotManager.refreshData();

            setTimeout(() => {
                this.classList.remove('iot-refreshing');
            }, 1000);
        });
    }

    // Initialize card expansion behavior
    const cards = document.querySelectorAll('.iot-card');
    cards.forEach(card => {
        const header = card.querySelector('.iot-card-header');
        const content = card.querySelector('.iot-card-content');
        const icon = card.querySelector('.iot-expand-icon');
        
        // Set initial state - first card expanded, others collapsed
        if (card === cards[0]) {
            content.style.display = 'block';
            icon.classList.add('iot-expanded');
        } else {
            content.style.display = 'none';
            icon.classList.remove('iot-expanded');
        }
        
        header.addEventListener('click', () => {
            const isExpanded = content.style.display === 'block';
            
            // Toggle the current card
            if (isExpanded) {
                content.style.display = 'none';
                icon.classList.remove('iot-expanded');
            } else {
                content.style.display = 'block';
                icon.classList.add('iot-expanded');
            }
        });
    });

    // Initialize UI elements from scripts2.js
    if (typeof initializeUIElements === 'function') {
        initializeUIElements();
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (iotManager) {
        iotManager.destroy();
    }
});

// Export for debugging if needed
window.IoTFirebaseManager = IoTFirebaseManager;

window.testIoT = function () {
    if (iotManager) iotManager.testWithMockData();
};

window.checkIoTStatus = function () {
    if (iotManager) {
        console.log('IoT Manager Status:', {
            isConnected: iotManager.isConnected,
            database: iotManager.database,
            sensorsRef: iotManager.sensorsRef,
            listeners: iotManager.listeners
        });
    }
};
