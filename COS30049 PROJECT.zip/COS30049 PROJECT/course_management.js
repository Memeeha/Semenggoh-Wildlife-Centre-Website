// Updated course_management.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  getDocs,
  doc,
  updateDoc
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// References to DOM elements
const tableBody = document.getElementById("trainingTableBody");
const editModal = document.getElementById("editModal");
const editTrainingDate = document.getElementById("editTrainingDate");
const editTrainingStatus = document.getElementById("editTrainingStatus");
const saveEditBtn = document.getElementById("saveEditBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");

let currentEditDocId = null;

// Get status badge class based on status
function getStatusBadgeClass(status) {
  switch(status.toLowerCase()) {
    case 'assigned':
      return 'status-badge status-assigned';
    case 'completed':
      return 'status-badge status-completed';
    case 'pending':
      return 'status-badge status-pending';
    default:
      return 'status-badge';
  }
}

// Format date to display nicely (YYYY-MM-DD -> DD MMM YYYY)
function formatDate(dateString) {
  if (!dateString) return "Not assigned";
  
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString; // Return original if invalid
  
  const options = { day: 'numeric', month: 'short', year: 'numeric' };
  return date.toLocaleDateString('en-US', options);
}

// Load training sessions from Firestore and render in table
async function loadTrainingSessions() {
  try {
    const querySnapshot = await getDocs(collection(db, "guide_courses"));
    
    if (querySnapshot.empty) {
      // Show empty state if no data
      tableBody.innerHTML = `
        <tr>
          <td colspan="5" class="empty-state">
            <i class="fas fa-folder-open"></i>
            <p>No training sessions found.</p>
          </td>
        </tr>
      `;
      return;
    }
    
    tableBody.innerHTML = "";

    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      const status = data.training_status || "N/A";
      const statusClass = getStatusBadgeClass(status);
      const formattedDate = formatDate(data.training_date);

      const row = document.createElement("tr");
      
      // Add data attributes for mobile view
      row.innerHTML = `
        <td data-label="Guide Name">${data.username || "N/A"}</td>
        <td data-label="Training Title">${data.course_name || "N/A"}</td>
        <td data-label="Training Date">${formattedDate}</td>
        <td data-label="Status"><span class="${statusClass}">${status}</span></td>
        <td data-label="Actions">
          <button type="button" 
                  class="edit-button" 
                  data-id="${docSnap.id}" 
                  data-date="${data.training_date || ""}" 
                  data-status="${status}">
            <i class="fas fa-edit"></i> Edit
          </button>
        </td>
      `;

      tableBody.appendChild(row);
    });

    attachEditEventListeners();
  } catch (error) {
    console.error("Error loading training sessions:", error);
    tableBody.innerHTML = `
      <tr>
        <td colspan="5" class="empty-state">
          <i class="fas fa-exclamation-triangle"></i>
          <p>Error loading training sessions. Please try again later.</p>
        </td>
      </tr>
    `;
  }
}

// Attach click events to edit buttons after rendering
function attachEditEventListeners() {
  document.querySelectorAll(".edit-button").forEach((button) => {
    button.addEventListener("click", () => {
      currentEditDocId = button.getAttribute("data-id");
      editTrainingDate.value = button.getAttribute("data-date");
      editTrainingStatus.value = button.getAttribute("data-status");
      editModal.style.display = "flex";
    });
  });
}

// Save changes to Firestore
saveEditBtn.addEventListener("click", async () => {
  const newDate = editTrainingDate.value;
  const newStatus = editTrainingStatus.value;

  if (!newDate || !newStatus) {
    alert("Both fields are required.");
    return;
  }

  try {
    const docRef = doc(db, "guide_courses", currentEditDocId);
    await updateDoc(docRef, {
      training_date: newDate,
      training_status: newStatus,
    });
    
    // Show success message
    const successMessage = document.createElement("div");
    successMessage.className = "success-message";
    successMessage.innerHTML = `<i class="fas fa-check-circle"></i> Training session updated successfully!`;
    document.body.appendChild(successMessage);
    
    setTimeout(() => {
      successMessage.style.opacity = "0";
      setTimeout(() => {
        document.body.removeChild(successMessage);
      }, 300);
    }, 2000);
    
    editModal.style.display = "none";
    loadTrainingSessions();
  } catch (err) {
    console.error("Error updating document:", err);
    alert("Failed to update training session.");
  }
});

// Hide modal on cancel
cancelEditBtn.addEventListener("click", () => {
  editModal.style.display = "none";
});

// Close modal when clicking outside
window.addEventListener("click", (event) => {
  if (event.target === editModal) {
    editModal.style.display = "none";
  }
});

// Add keydown event for accessibility
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && editModal.style.display === "flex") {
    editModal.style.display = "none";
  }
});

// Additional CSS for success message
const style = document.createElement("style");
style.textContent = `
  .success-message {
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #10b981;
    color: white;
    padding: 15px 20px;
    border-radius: 5px;
    display: flex;
    align-items: center;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 1001;
    transition: opacity 0.3s ease;
  }
  
  .success-message i {
    margin-right: 10px;
  }
`;
document.head.appendChild(style);

// Load data on page load
document.addEventListener("DOMContentLoaded", () => {
  loadTrainingSessions();
});

// If the page is already loaded, run it now
if (document.readyState === "complete" || document.readyState === "interactive") {
  loadTrainingSessions();
}