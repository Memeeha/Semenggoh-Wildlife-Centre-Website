import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getDatabase, ref, onValue, push, query, orderByChild, limitToLast, get } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js";
import { firebaseConfig } from "./firebase-config2.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const database = getDatabase(app);

// Reference to the buttonPressed node in Firebase
const buttonRef = ref(database, 'sensors/buttonPressed');
const notificationsRef = ref(database, 'notifications');

// Track previous button state to detect changes
let previousButtonState = null;

// Wait for DOM to be ready
document.addEventListener('DOMContentLoaded', function() {
    console.log("DOM loaded, setting up notification system...");
    
    // Initialize notification count from existing notifications
    loadNotificationCount();
    
    // Set up notification bell click handler
    setupNotificationBell();
});

// Function to load existing notification count
function loadNotificationCount() {
    get(notificationsRef).then((snapshot) => {
        const notifications = snapshot.val();
        if (notifications) {
            const count = Object.keys(notifications).length;
            updateNotificationCount(count);
            console.log("Loaded existing notifications:", count);
        }
    }).catch((error) => {
        console.error("Error loading notification count:", error);
    });
}

// Function to update notification count display
function updateNotificationCount(count) {
    const notificationCountElement = document.getElementById('notification-count');
    if (notificationCountElement) {
        notificationCountElement.innerText = count;
        notificationCountElement.style.display = count > 0 ? 'inline' : 'none';
    }
}

// Function to setup notification bell click handler
function setupNotificationBell() {
    const notificationBell = document.getElementById('notification-bell');
    if (notificationBell) {
        notificationBell.addEventListener('click', function(e) {
            e.preventDefault();
            console.log("Notification bell clicked");
            
            const dropdown = document.getElementById('notification-dropdown');
            if (dropdown) {
                const isVisible = dropdown.style.display === 'block';
                dropdown.style.display = isVisible ? 'none' : 'block';
                
                if (!isVisible) {
                    loadNotifications();
                }
            }
        });
        console.log("Notification bell event listener attached");
    } else {
        console.error("Notification bell element not found");
    }
}

// Function to load and display notifications
function loadNotifications() {
    console.log("Loading notifications...");
    
    const notificationsQuery = query(notificationsRef, orderByChild('timestamp'), limitToLast(10));
    
    get(notificationsQuery).then((snapshot) => {
        const notifications = snapshot.val();
        const notificationList = document.getElementById('notification-list');
        
        if (!notificationList) {
            console.error("Notification list element not found");
            return;
        }
        
        notificationList.innerHTML = ''; // Clear current notifications

        if (notifications) {
            console.log("Found notifications:", Object.keys(notifications).length);
            
            // Convert to array and reverse to show newest first
            const notificationArray = Object.entries(notifications)
                .map(([key, notification]) => ({ key, ...notification }))
                .sort((a, b) => b.timestamp - a.timestamp);
            
            notificationArray.forEach((notification) => {
                const li = document.createElement('li');
                const date = new Date(notification.timestamp);
                li.innerHTML = `
                    <div style="font-weight: bold; color: #d32f2f;">${notification.message}</div>
                    <div style="font-size: 12px; color: #666; margin-top: 4px;">${date.toLocaleString()}</div>
                `;
                notificationList.appendChild(li);
            });
        } else {
            console.log("No notifications found");
            const li = document.createElement('li');
            li.innerHTML = '<div style="color: #666; font-style: italic;">No notifications</div>';
            notificationList.appendChild(li);
        }
    }).catch((error) => {
        console.error("Error fetching notifications:", error);
    });
}

// Listen for changes in the buttonPressed state (intruder detection)
onValue(buttonRef, function(snapshot) {
    const buttonState = snapshot.val();
    
    console.log("Button state from Firebase:", buttonState);
    console.log("Previous button state:", previousButtonState);

    // Check if button state changed from false to true (button was pressed)
    if (previousButtonState === false && buttonState === true) {
        console.log("Button press detected! Creating notification...");
        
        const newNotification = {
            message: 'Intruder Alert! Unauthorized access detected',
            timestamp: Date.now(),
            type: 'security_alert'
        };

        // Push the new notification to Firebase
        push(notificationsRef, newNotification).then(() => {
            console.log("Notification saved to Firebase");
            
            // Show immediate alert
            alert("🚨 SECURITY ALERT: An intruder has been detected!");
            
            // Update notification count
            loadNotificationCount();
            
        }).catch((error) => {
            console.error("Error saving notification:", error);
        });
    }
    
    // Update previous state
    previousButtonState = buttonState;
});

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('notification-dropdown');
    const bell = document.getElementById('notification-bell');
    
    if (dropdown && bell && !bell.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.style.display = 'none';
    }
});

// Logout function
function logout() {
    signOut(auth).then(() => {
        window.location.href = "adminLogin.html";
    }).catch((error) => {
        console.error("Error signing out:", error);
    });
}

// Get the currently logged in user and display their name
onAuthStateChanged(auth, async function(user) {
    if (user) {
        const uid = user.uid;
        console.log("User authenticated:", uid);

        try {
            const adminDocRef = doc(db, "admins", uid);
            const adminDoc = await getDoc(adminDocRef);
            
            const adminNameElement = document.getElementById("admin-name");
            if (adminNameElement) {
                if (adminDoc.exists()) {
                    const adminName = adminDoc.data().name;
                    adminNameElement.textContent = ", " + adminName;
                } else {
                    // fallback: use email username
                    const emailUsername = user.email.split("@")[0];
                    adminNameElement.textContent = ", " + emailUsername;
                }
            }
        } catch (error) {
            console.error("Error fetching admin data:", error);
        }
    } else {
        console.log("No user authenticated, redirecting to login");
        // No user signed in, redirect to login page
        window.location.href = "adminLogin.html";
    }
});

// Test function to manually trigger notification (for testing purposes)
async function testNotification() {
    const newNotification = {
        message: 'Test notification - System working correctly',
        timestamp: Date.now(),
        type: 'test'
    };

    try {
        await push(notificationsRef, newNotification);
        console.log("Test notification created");
        loadNotificationCount();
        alert("Test notification created!");
    } catch (error) {
        console.error("Error creating test notification:", error);
    }
}

window.testNotification = testNotification;
