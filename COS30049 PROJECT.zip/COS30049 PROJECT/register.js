// register.js

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js"; // make sure this file exports firebaseConfig

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.querySelector("form").addEventListener("submit", async function (e) {
  e.preventDefault();

  const fullName = document.getElementById("full_name").value;
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const phone = document.getElementById("phone").value;
  const email = document.getElementById("email").value;
  const dob = document.getElementById("dob").value;
  const employmentDate = document.getElementById("employment_date").value;
  const experience = parseInt(document.getElementById("experience").value);
  const specialties = document.getElementById("specialties").value;

  // Languages
  const checkedLangs = Array.from(document.querySelectorAll("input[name='languages[]']:checked")).map(el => el.value);
  const otherLang = document.getElementById("myTextbox").value.trim();
  if (otherLang) checkedLangs.push(otherLang);

  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const userId = userCredential.user.uid;

    await setDoc(doc(db, "park_guides", userId), {
      fullName,
      username,
      phone,
      email,
      dob,
      employmentDate,
      experience,
      specialties,
      languages: checkedLangs,
      approved: false,
      createdAt: serverTimestamp()
    });

    alert("Registration successful!");
    e.target.reset();
  } catch (error) {
    console.error(error);
    alert("Error: " + error.message);
  }
});
