// guide_quiz_improved.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { 
  getFirestore, 
  collection, 
  getDocs, 
  addDoc, 
  doc, 
  getDoc 
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js"; // Your Firebase configuration

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Global variables
let questions = [];
let currentQuestionIndex = 0;
let userAnswers = [];
let quizTimer;
let timeRemaining = 600; // 10 minutes in seconds
let guideFullName = "Anonymous Guide"; // Default values
let guideUsername = "anonymous";

// Fetch quiz questions from Firebase Firestore
async function fetchQuizQuestions() {
  try {
    const questionsRef = collection(db, 'quiz_questions');
    const querySnapshot = await getDocs(questionsRef);
    
    const allQuestions = [];
    querySnapshot.forEach((doc) => {
      allQuestions.push({
        id: doc.id,
        ...doc.data(),
      });
    });

    console.log("Fetched Questions:", allQuestions); // Log the fetched questions

    // Shuffle and limit to 5 random questions
    const shuffledQuestions = allQuestions.sort(() => Math.random() - 0.5).slice(0, 5);
    return shuffledQuestions;
  } catch (error) {
    console.error("Error fetching questions:", error);
    document.getElementById('question').textContent = "Failed to load questions from database. Please try again later.";
    throw new Error("Failed to load questions from Firebase");
  }
}

// Function to fetch guide information from Firebase
async function fetchGuideInfo(userId) {
  try {
    const guideRef = doc(db, "guides", userId);
    const guideSnap = await getDoc(guideRef);
    
    if (guideSnap.exists()) {
      const guideData = guideSnap.data();
      // Store the guide's information in global variables and localStorage
      guideFullName = guideData.fullName || "Anonymous Guide";
      guideUsername = guideData.username || "anonymous";
      
      localStorage.setItem('guideFullName', guideFullName);
      localStorage.setItem('guideUsername', guideUsername);
      
      console.log("Guide info loaded:", guideFullName, guideUsername);
      return { guideFullName, guideUsername };
    } else {
      console.log("No guide data found for user ID:", userId);
      return null;
    }
  } catch (error) {
    console.error("Error fetching guide info:", error);
    return null;
  }
}

// Function to save score to Firebase
async function saveScoreToFirebase(score, correctAnswers, totalQuestions) {
  try {
    // Get user data from localStorage or use defaults
    const userId = localStorage.getItem('userId') || "anonymous_user";
    
    // Make sure guide information is loaded
    if (!guideFullName || !guideUsername) {
      guideFullName = localStorage.getItem('guideFullName') || "Anonymous Guide";
      guideUsername = localStorage.getItem('guideUsername') || "anonymous";
    }

    // Calculate pass/fail status
    const status = correctAnswers >= 3 ? "Passed" : "Failed";
    
    // Create the performance record
    const performanceData = {
      guideId: userId,
      guideName: guideFullName,
      guideUsername: guideUsername,
      status: status,
      score: score,
      correctAnswers: correctAnswers,
      totalQuestions: totalQuestions,
      date: new Date()
    };
    
    // Save to Firestore
    const docRef = await addDoc(collection(db, 'guide_performance'), performanceData);
    console.log("Score saved successfully with ID:", docRef.id);
    
    return docRef.id;
  } catch (error) {
    console.error("Error saving score:", error);
    // Show error message to user
    const feedbackElem = document.getElementById('quiz-feedback');
    if (feedbackElem) {
      feedbackElem.textContent += " (Note: There was an issue saving your results)";
    }
    return null;
  }
}

// Start the timer
function startTimer() {
  const timeRemainingElem = document.getElementById('time-remaining');
  
  quizTimer = setInterval(function() {
    timeRemaining--;
    
    const minutes = Math.floor(timeRemaining / 60);
    const seconds = timeRemaining % 60;
    
    timeRemainingElem.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    
    if (timeRemaining <= 0) {
      clearInterval(quizTimer);
      finishQuiz(); // Auto-submit when time runs out
    }
  }, 1000);
}

// Display the current question and options
function displayQuestion() {
  const questionElem = document.getElementById('question');
  const optionsContainer = document.getElementById('options');
  const question = questions[currentQuestionIndex];

  // Update question text
  questionElem.textContent = question.question;

  // Clear previous options
  optionsContainer.innerHTML = '';
  
  // Add options and mark selected if user previously answered
  question.options.forEach((option, index) => {
    const optionElem = document.createElement('li');
    optionElem.classList.add('guide_quiz-option');
    optionElem.textContent = option;
    optionElem.dataset.value = option; // Store the actual option text as the value
    
    // If user already answered this question, show their selection
    if (userAnswers[currentQuestionIndex] === option) {
      optionElem.classList.add('selected');
    }
    
    optionsContainer.appendChild(optionElem);
  });

  // Update progress bar
  updateProgressBar();

  // Update button states
  updateButtonStates();
}

// Update progress bar based on current question
function updateProgressBar() {
  const progressBar = document.getElementById('progress');
  const progressPercentage = document.getElementById('progress-percentage');
  const currentQuestionElem = document.getElementById('current-question');
  const totalQuestionsElem = document.getElementById('total-questions');
  
  const progressValue = ((currentQuestionIndex + 1) / questions.length) * 100;
  progressBar.style.width = progressValue + '%';
  progressPercentage.textContent = Math.round(progressValue) + '%';
  currentQuestionElem.textContent = currentQuestionIndex + 1;
  totalQuestionsElem.textContent = questions.length;
}

// Update navigation button states
function updateButtonStates() {
  const prevBtn = document.getElementById('prev-btn');
  const nextBtn = document.getElementById('next-btn');
  
  prevBtn.disabled = currentQuestionIndex === 0;
  nextBtn.textContent = currentQuestionIndex === questions.length - 1 ? "Finish" : "Next";
}

// Calculate score based on user answers
function calculateScore() {
  let correctCount = 0;
  
  userAnswers.forEach((answer, index) => {
    // Compare the user's answer (which is the option text) with the correct answer from the question
    if (answer === questions[index].correctAnswer) {
      correctCount++;
    }
  });
  
  return {
    percentage: Math.round((correctCount / questions.length) * 100),
    correct: correctCount,
    total: questions.length
  };
}

// Display the final results
function finishQuiz() {
  // Stop the timer if it's running
  if (quizTimer) {
    clearInterval(quizTimer);
  }

  // Calculate score
  const result = calculateScore();
  
  // Display results
  const resultsSection = document.getElementById('results');
  resultsSection.style.display = 'block';
  document.getElementById('question-container').style.display = 'none';
  document.getElementById('score').textContent = result.percentage;
  document.getElementById('correct-answers').textContent = result.correct;
  document.getElementById('total-answers').textContent = result.total;

  // Show appropriate feedback based on score
  const feedbackElem = document.getElementById('quiz-feedback');
  if (result.correct >= 3) { // 3 out of 5 is a pass
    feedbackElem.textContent = "Congratulations! You've demonstrated solid knowledge of Semenggoh Wildlife Centre.";
    feedbackElem.classList.add('success-feedback');
  } else {
    feedbackElem.textContent = "You need to improve your knowledge about Semenggoh Wildlife Centre. Please take the quiz again.";
    feedbackElem.classList.add('failure-feedback');
  }

  // Hide navigation buttons
  document.querySelector('.guide_quiz-navigation').style.display = 'none';
  
  // Save score to Firebase
  saveScoreToFirebase(result.percentage, result.correct, result.total)
    .then((docId) => {
      if (docId) {
        console.log("Results saved with ID:", docId);
      }
    });
  
  // Update the SVG circle for score visualization
  updateScoreCircle(result.percentage);
}

// Update the SVG circle progress based on score percentage
function updateScoreCircle(scorePercentage) {
  const circle = document.querySelector('.guide_quiz-circle-progress');
  if (!circle) {
    console.error("Score circle element not found");
    return;
  }
  
  const radius = parseInt(circle.getAttribute('r'));
  const circumference = 2 * Math.PI * radius;
  
  // Calculate stroke-dashoffset
  const offset = circumference - (circumference * scorePercentage / 100);
  
  // Apply the dasharray and dashoffset
  circle.style.strokeDasharray = circumference;
  circle.style.strokeDashoffset = offset;

  // Update the score text inside the circle
  const scoreElem = document.getElementById('score');
  if (scoreElem) {
    scoreElem.textContent = scorePercentage;
  }
}

// Initialize quiz application
async function initializeQuiz() {
  try {
    // First, get the user ID and guide information
    const userId = localStorage.getItem('userId') || "anonymous_user";
    await fetchGuideInfo(userId);
    
    // Then fetch questions and start the quiz
    questions = await fetchQuizQuestions();
    
    // Initialize user answers array
    userAnswers = Array(questions.length).fill(null);
    
    // Start the timer
    startTimer();
    
    // Display the first question
    displayQuestion();
    
    console.log("Quiz initialized successfully");
    return true;
  } catch (error) {
    console.error("Failed to initialize quiz:", error);
    document.getElementById('question').textContent = 
      "There was a problem loading the quiz. Please refresh the page or try again later.";
    return false;
  }
}

// Document ready function
document.addEventListener('DOMContentLoaded', function() {
  // Initialize the quiz
  initializeQuiz();
  
  // Handle option selection
  document.getElementById('options').addEventListener('click', function(e) {
    if (e.target.classList.contains('guide_quiz-option')) {
      // Remove 'selected' class from all options
      document.querySelectorAll('.guide_quiz-option').forEach(option => {
        option.classList.remove('selected');
      });
      
      // Add 'selected' class to clicked option
      e.target.classList.add('selected');
      
      // Save user's answer as the option text (not the index)
      userAnswers[currentQuestionIndex] = e.target.dataset.value;
    }
  });
  
  // Handle Previous button click
  document.getElementById('prev-btn').addEventListener('click', function() {
    if (currentQuestionIndex > 0) {
      currentQuestionIndex--;
      displayQuestion();
    }
  });
  
  // Handle Next button click
  document.getElementById('next-btn').addEventListener('click', function() {
    if (currentQuestionIndex < questions.length - 1) {
      currentQuestionIndex++;
      displayQuestion();
    } else {
      finishQuiz();
    }
  });
  
  // Handle Review Answers button
  document.getElementById('review-btn').addEventListener('click', function() {
    // Reset to first question
    currentQuestionIndex = 0;
    
    // Show question container, hide results
    document.getElementById('question-container').style.display = 'block';
    document.getElementById('results').style.display = 'none';
    document.querySelector('.guide_quiz-navigation').style.display = 'flex';
    
    // Show questions in review mode (disable changing answers)
    displayQuestion();
  });
  
  // Handle Retry Quiz button
  document.getElementById('retry-btn').addEventListener('click', function() {
    // Reload the page to restart the quiz with new questions
    window.location.reload();
  });
});

// Export functions for use in other files
export { fetchQuizQuestions, saveScoreToFirebase };