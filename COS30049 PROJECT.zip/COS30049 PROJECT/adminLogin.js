import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// EmailJS configuration
const EMAILJS_SERVICE_ID = "service_us1byu4";
const EMAILJS_TEMPLATE_ID = "template_7vvuje8";
const EMAILJS_PUBLIC_KEY = "zUGDJ6tyI0F2Ipr40";

// Initialize EmailJS
emailjs.init(EMAILJS_PUBLIC_KEY);

// DOM Elements
const sendOtpBtn = document.getElementById("sendOtpBtn");
const loginForm = document.getElementById("loginForm");
const loginBtn = document.getElementById("loginBtn");
const otpSection = document.getElementById("otpSection");

let currentUid = null;
let otpSent = false;

// reCAPTCHA v2 validation function
function validateRecaptcha() {
  const recaptchaResponse = grecaptcha.getResponse();
  if (recaptchaResponse.length === 0) {
    alert("Please complete the reCAPTCHA verification.");
    return false;
  }
  return true;
}

// Step 1: Send OTP
sendOtpBtn.addEventListener("click", async () => {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  // Validate reCAPTCHA
  if (!validateRecaptcha()) {
    return;
  }

  try {
    console.log("Attempting to send OTP to:", email);

    // Firebase sign-in
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const uid = userCredential.user.uid;
    currentUid = uid;

    // Check if admin exists in Firestore
    const adminRef = doc(db, "admins", uid);
    const adminSnap = await getDoc(adminRef);
    if (!adminSnap.exists()) {
      alert("Access denied. You are not registered as an admin.");
      return;
    }

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 15 * 60 * 1000; // 15 minutes
    const expiryTime = new Date(expiresAt).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    });

    // Save OTP to Firestore
    await setDoc(doc(db, "adminOtps", uid), { otp, expiresAt });

    // Create EmailJS parameters to match your template
    const emailParams = {
      email: email,          // This needs to match {{email}} in your template
      passcode: otp,         // This needs to match {{passcode}} in your template
      time: expiryTime       // This needs to match {{time}} in your template
    };
    
    console.log("Sending EmailJS with params:", emailParams);
    
    // Send OTP via EmailJS
    const response = await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, emailParams);
    console.log("EmailJS response:", response);

    // Show OTP input section
    otpSection.style.display = "block";
    loginBtn.style.display = "inline-block";
    sendOtpBtn.disabled = true;
    otpSent = true;

    alert("OTP sent to your email. Please check and enter it to proceed.");
  } catch (error) {
    console.error("Send OTP Error:", error);
    alert("Failed to send OTP email: " + (error.text || error.message));
  }
});

// Step 2: Verify OTP and complete login
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const enteredOtp = document.getElementById("otp").value.trim();

  // Validate reCAPTCHA again for final login
  if (!validateRecaptcha()) {
    return;
  }

  if (!otpSent || !currentUid) {
    alert("Please request an OTP first.");
    return;
  }

  try {
    const otpDoc = await getDoc(doc(db, "adminOtps", currentUid));
    if (!otpDoc.exists()) {
      alert("OTP not found. Please request a new one.");
      return;
    }

    const { otp, expiresAt } = otpDoc.data();

    if (Date.now() > expiresAt) {
      alert("OTP expired. Please request a new one.");
      document.getElementById("otp").value = "";
      return;
    }

    if (enteredOtp !== otp) {
      alert("Invalid OTP. Please try again.");
      document.getElementById("otp").value = "";
      return;
    }

    alert("Admin login successful!");
    window.location.href = "adminHomepage.html";
  } catch (error) {
    console.error("OTP Verification Error:", error);
    alert("Login failed: " + error.message);
  }
});