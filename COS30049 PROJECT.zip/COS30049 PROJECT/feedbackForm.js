// feedbackForm.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDx5Zx5wG0xKfWvLXfXx2X9jkc-fcHa-H0",
  authDomain: "test-9d9ca.firebaseapp.com",
  projectId: "test-9d9ca",
  storageBucket: "test-9d9ca.firebasestorage.app",
  messagingSenderId: "84555163784",
  appId: "1:84555163784:web:14c0267fb44e3671fa173d",
  measurementId: "G-XGMP3PJJK8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Get the form element
const feedbackForm = document.getElementById("feedbackForm");

feedbackForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const guideName = document.getElementById("guideName").value;
  const engRating = document.getElementById("engRating").value;
  const bmRating = document.getElementById("bmRating").value;
  const chiRating = document.getElementById("chiRating").value;
  const knowledgeFeedback = document.getElementById("knowledgeFeedback").value;

  try {
    // Add the feedback data to Firestore
    await addDoc(collection(db, "feedbacks"), {
      guideName: guideName,
      engRating: parseInt(engRating),
      bmRating: parseInt(bmRating),
      chiRating: parseInt(chiRating),
      knowledgeFeedback: knowledgeFeedback,
      timestamp: new Date(),
    });

    // Confirmation message after submission
    alert("Thank you for your feedback!");
    feedbackForm.reset();
  } catch (error) {
    console.error("Error adding document: ", error);
    alert("There was an error submitting your feedback. Please try again.");
  }
});