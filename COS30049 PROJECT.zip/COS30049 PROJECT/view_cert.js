import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, getDocs, updateDoc, doc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const tableBody = document.getElementById("certTableBody");

async function fetchCertifications() {
  try {
    // Clear previous rows
    tableBody.innerHTML = "";

    const querySnapshot = await getDocs(collection(db, "certification_renewal"));

    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();

      // ❌ Skip if already processed
      if (data.status === "Approved" || data.status === "Rejected") return;

      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${data.fullName || ""}</td>
        <td>${data.username || ""}</td>
        <td>${data.email || ""}</td>
        <td>${data.testMarks || ""}</td>
        <td>${data.certifications || ""}</td>
        <td>${data.certExpiry || ""}</td>
        <td>
          ${data.uploadedFiles?.map(url => `<a href="${url}" target="_blank">View</a>`).join(", ") || "No files"}
        </td>
        <td>${data.timestamp?.toDate ? data.timestamp.toDate().toLocaleString() : ""}</td>
        <td>${data.status || "Pending"}</td>
        <td>
          <button class="approve-btn" data-id="${docSnap.id}">Approve</button>
          <button class="reject-btn" data-id="${docSnap.id}">Reject</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error("Error loading certifications:", error);
  }
}

// Approve/Reject logic
tableBody.addEventListener("click", async (e) => {
  if (e.target.classList.contains("approve-btn") || e.target.classList.contains("reject-btn")) {
    const docId = e.target.getAttribute("data-id");
    const status = e.target.classList.contains("approve-btn") ? "Approved" : "Rejected";

    try {
      await updateDoc(doc(db, "certification_renewal", docId), { status });
      alert(`Submission ${status.toLowerCase()} successfully.`);

      // Re-fetch to update the table and remove the row
      await fetchCertifications();
    } catch (error) {
      console.error("Status update failed:", error);
      alert("Error updating status.");
    }
  }
});

// Initial fetch
fetchCertifications();
