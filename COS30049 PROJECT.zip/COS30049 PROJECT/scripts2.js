document.addEventListener('DOMContentLoaded', function() {
    // Mobile Sidebar Toggle
    const hamburger = document.querySelector('.mobile-nav-toggle');
    const sidebar = document.querySelector('.sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    const closeBtn = document.querySelector('.close-sidebar');
    
    if (hamburger && sidebar && overlay && closeBtn) {
        hamburger.addEventListener('click', function() {
            sidebar.classList.add('active');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
        
        closeBtn.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = 'auto';
        });
        
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = 'auto';
        });
    }

    // Mobile Dropdowns
    const dropdowns = document.querySelectorAll('.sidebar-item.dropdown > a');
    
    if (dropdowns.length > 0) {
        dropdowns.forEach(dropdown => {
            dropdown.addEventListener('click', function(e) {
                e.preventDefault();
                const menu = this.nextElementSibling;
                const icon = this.querySelector('.dropdown-icon');
                
                // Close other dropdowns
                document.querySelectorAll('.dropdown-menu').forEach(otherMenu => {
                    if (otherMenu !== menu) {
                        otherMenu.style.maxHeight = null;
                        const prevIcon = otherMenu.previousElementSibling.querySelector('.dropdown-icon');
                        if (prevIcon) prevIcon.classList.remove('rotate');
                    }
                });
                
                // Toggle current dropdown
                if (menu) {
                    if (menu.style.maxHeight) {
                        menu.style.maxHeight = null;
                        if (icon) icon.classList.remove('rotate');
                    } else {
                        menu.style.maxHeight = menu.scrollHeight + 'px';
                        if (icon) icon.classList.add('rotate');
                    }
                }
            });
        });
    }

    // Desktop Dropdowns
    const desktopDropdowns = document.querySelectorAll('.dropdown');
    
    if (desktopDropdowns.length > 0) {
        desktopDropdowns.forEach(dropdown => {
            dropdown.addEventListener('mouseenter', function() {
                const menu = this.querySelector('.dropdown-menu');
                const icon = this.querySelector('.dropdown-icon');
                if (menu) {
                    menu.style.opacity = '1';
                    menu.style.visibility = 'visible';
                    menu.style.transform = 'translateY(0)';
                }
                if (icon) icon.classList.add('rotate');
            });
            
            dropdown.addEventListener('mouseleave', function() {
                const menu = this.querySelector('.dropdown-menu');
                const icon = this.querySelector('.dropdown-icon');
                if (menu) {
                    menu.style.opacity = '0';
                    menu.style.visibility = 'hidden';
                    menu.style.transform = 'translateY(10px)';
                }
                if (icon) icon.classList.remove('rotate');
            });
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    // Slideshow
    let slideIndex = 1;
    showSlides(slideIndex);

    let slideInterval;

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        let i;
        let slides = document.getElementsByClassName("slide");
        let dots = document.getElementsByClassName("dot");
        if (!slides.length) return;

        if (n > slides.length) { slideIndex = 1 }
        if (n < 1) { slideIndex = slides.length }

        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex - 1].style.display = "block";
        if (dots[slideIndex - 1]) dots[slideIndex - 1].className += " active";
    }

    slideInterval = setInterval(function() {
        plusSlides(1);
    }, 6000);

    const slideshowContainer = document.querySelector('.slideshow-container');

    if (slideshowContainer) {
        slideshowContainer.addEventListener('mouseenter', function() {
            clearInterval(slideInterval);
        });
        slideshowContainer.addEventListener('mouseleave', function() {
            clearInterval(slideInterval);
            slideInterval = setInterval(function() {
                plusSlides(1);
            }, 6000);
        });
    }

    window.plusSlides = plusSlides;
    window.currentSlide = currentSlide;
});

document.addEventListener('DOMContentLoaded', function() {

    refreshBtn.addEventListener('click', refreshCaptcha);

    function showError(input, message) {
        if (!input) return;
        input.classList.add('error');
        const errorElement = input.parentElement.querySelector('.error-message');
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
    }

    function hideError(input) {
        if (!input) return;
        input.classList.remove('error');
        const errorElement = input.parentElement.querySelector('.error-message');
        if (errorElement) {
            errorElement.style.display = 'none';
        }
    }

    function validateForm() {
        let isValid = true;

        if (usernameInput.value.trim().length < 3) {
            showError(usernameInput, 'Username must be at least 3 characters');
            isValid = false;
        } else {
            hideError(usernameInput);
        }

        if (passwordInput.value.length < 6) {
            showError(passwordInput, 'Password must be at least 6 characters');
            isValid = false;
        } else {
            hideError(passwordInput);
        }

        if (!captchaCheck.checked) {
            alert('Please confirm you are not a robot');
            isValid = false;
        }

        return isValid;
    }

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();

        if (validateForm()) {
            loginBtn.classList.add('loading');

            setTimeout(function() {
                loginBtn.classList.remove('loading');
                alert('Login successful! Redirecting to dashboard...');
                window.location.href = 'dashboard.html';
            }, 2000);
        }
    });

    usernameInput.addEventListener('blur', function() {
        if (this.value.trim().length < 3) {
            showError(this, 'Username must be at least 3 characters');
        } else {
            hideError(this);
        }
    });

    passwordInput.addEventListener('blur', function() {
        if (this.value.length < 6) {
            showError(this, 'Password must be at least 6 characters');
        } else {
            hideError(this);
        }
    });

    // Password show/hide
    const togglePassword = document.createElement('i');
    togglePassword.className = 'fas fa-eye form-icon';
    togglePassword.style.cursor = 'pointer';
    togglePassword.style.position = 'absolute';
    togglePassword.style.right = '15px';
    togglePassword.style.top = '50%';
    togglePassword.style.transform = 'translateY(-50%)';
    togglePassword.style.zIndex = '10';

    passwordInput.parentElement.style.position = 'relative'; // make sure parent is positioned
    passwordInput.parentElement.appendChild(togglePassword);

    togglePassword.addEventListener('click', function() {
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            togglePassword.className = 'fas fa-eye-slash form-icon';
        } else {
            passwordInput.type = 'password';
            togglePassword.className = 'fas fa-eye form-icon';
        }
    });

    // Animate feature items on scroll
    const featureItems = document.querySelectorAll('.feature-item');

    if (featureItems.length > 0) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.2 });

        featureItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            item.style.transition = `all 0.5s ease ${index * 0.1}s`;
            observer.observe(item);
        });
    }
});

// Feedback form star ratings
function updateStars(rating, starsContainer) {
    if (!starsContainer) return;
    const stars = starsContainer.getElementsByTagName('i');
    for (let i = 0; i < stars.length; i++) {
        stars[i].classList.toggle('active', i < rating);
    }
}

const engRating = document.getElementById('engRating');
const bmRating = document.getElementById('bmRating');
const chiRating = document.getElementById('chiRating');

if (engRating) {
    engRating.addEventListener('input', function() {
        updateStars(this.value, document.getElementById('engStars'));
    });
}

if (bmRating) {
    bmRating.addEventListener('input', function() {
        updateStars(this.value, document.getElementById('bmStars'));
    });
}

if (chiRating) {
    chiRating.addEventListener('input', function() {
        updateStars(this.value, document.getElementById('chiStars'));
    });
}

// admin announcement page
    document.addEventListener('DOMContentLoaded', function() {
      // Variables
      const addBtn = document.getElementById('admin_announcement-addBtn');
      const formSection = document.getElementById('admin_announcement-formSection');
      const cancelBtn = document.getElementById('admin_announcement-cancelBtn');
      const deleteModal = document.getElementById('admin_announcement-deleteModal');
      const cancelDeleteBtn = document.getElementById('admin_announcement-cancelDeleteBtn');
      
      // Show form when Add button is clicked
      addBtn.addEventListener('click', function() {
        formSection.style.display = 'block';
        document.getElementById('admin_announcement-formTitle').textContent = 'Create New Announcement';
        document.getElementById('admin_announcement-form').reset();
      });
      
      // Hide form when Cancel button is clicked
      cancelBtn.addEventListener('click', function() {
        formSection.style.display = 'none';
      });
      
      // Close delete modal when Cancel is clicked
      cancelDeleteBtn.addEventListener('click', function() {
        deleteModal.classList.remove('show');
      });
      
      // Function to show delete modal (to be called from your existing code)
      window.showDeleteConfirmation = function() {
        deleteModal.classList.add('show');
      };
      
      // Connect to your existing functions
      // These should be integrated with your existing Firebase functions
      window.customEditAnnouncement = function(id) {
        // Call your existing edit function, then:
        formSection.style.display = 'block';
        document.getElementById('admin_announcement-formTitle').textContent = 'Edit Announcement';
        // Your code to populate the form with existing data
      };
        window.customDeleteAnnouncement = function(id) {}
    // Close modal when clicking outside
      window.addEventListener('click', function(event) {
        if (event.target === deleteModal) {
          deleteModal.classList.remove('show');
        }
      });
    });

// Admin Dashboard Pagination Implementation
document.addEventListener('DOMContentLoaded', function() {
    // Elements per page - adjust as needed
    const itemsPerPage = 6;
    const featureCards = document.querySelectorAll('.feature-card');
    
    // Only apply pagination if there are more cards than itemsPerPage
    if (featureCards.length > itemsPerPage) {
        // Add a specific class to feature cards for this pagination system
        featureCards.forEach(card => {
            card.classList.add('admin-feature-card');
        });
        
        setupAdminPagination(featureCards, itemsPerPage);
    }
});

function setupAdminPagination(items, itemsPerPage) {
    const featuresSection = document.querySelector('.features-section');
    const featuresContainer = document.querySelector('.features-container');
    
    // Calculate total pages
    const totalPages = Math.ceil(items.length / itemsPerPage);
    let currentPage = 1;
    
    // Create pagination container
    const paginationContainer = document.createElement('div');
    paginationContainer.className = 'admin-features-pagination';
    
    // Create previous button
    const prevItem = document.createElement('div');
    prevItem.className = 'admin_homepage-page-item disabled';
    const prevLink = document.createElement('button');
    prevLink.className = 'admin_homepage-page-link';
    prevLink.innerHTML = '<i class="fas fa-chevron-left"></i>';
    prevItem.appendChild(prevLink);
    paginationContainer.appendChild(prevItem);
    
    // Create number buttons
    for (let i = 1; i <= totalPages; i++) {
        const pageItem = document.createElement('div');
        pageItem.className = 'admin_homepage-page-item' + (i === 1 ? ' active' : '');
        
        const pageLink = document.createElement('button');
        pageLink.className = 'admin_homepage-page-link';
        pageLink.textContent = i;
        
        pageItem.appendChild(pageLink);
        paginationContainer.appendChild(pageItem);
    }
    
    // Create next button
    const nextItem = document.createElement('div');
    nextItem.className = 'admin_homepage-page-item';
    const nextLink = document.createElement('button');
    nextLink.className = 'admin_homepage-page-link';
    nextLink.innerHTML = '<i class="fas fa-chevron-right"></i>';
    nextItem.appendChild(nextLink);
    paginationContainer.appendChild(nextItem);
    
    // Add pagination container after features container
    featuresSection.insertBefore(paginationContainer, featuresContainer.nextSibling);
    
    // Initial display
    displayAdminItems(items, currentPage, itemsPerPage);
    
    // Add event listeners to all pagination buttons
    const pageButtons = document.querySelectorAll('.admin_homepage-page-link');
    pageButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            // For previous button
            if (index === 0) {
                if (currentPage > 1) {
                    currentPage--;
                    displayAdminItems(items, currentPage, itemsPerPage);
                    updateAdminPaginationState(totalPages, currentPage);
                }
                return;
            }
            
            // For next button
            if (index === pageButtons.length - 1) {
                if (currentPage < totalPages) {
                    currentPage++;
                    displayAdminItems(items, currentPage, itemsPerPage);
                    updateAdminPaginationState(totalPages, currentPage);
                }
                return;
            }
            
            // For number buttons
            currentPage = index;
            displayAdminItems(items, currentPage, itemsPerPage);
            updateAdminPaginationState(totalPages, currentPage);
        });
    });
}

function displayAdminItems(items, currentPage, itemsPerPage) {
    // Calculate start and end indices for current page
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    
    // Hide all items first
    items.forEach((item, index) => {
        if (index >= startIndex && index < endIndex) {
            item.classList.remove('hidden');
            item.classList.add('visible');
        } else {
            item.classList.remove('visible');
            item.classList.add('hidden');
        }
    });
}

function updateAdminPaginationState(totalPages, currentPage) {
    // Update active state for number buttons
    const pageItems = document.querySelectorAll('.admin_homepage-page-item');
    
    pageItems.forEach((item, index) => {
        // Skip prev and next buttons
        if (index === 0 || index === pageItems.length - 1) {
            return;
        }
        
        // Update number buttons' active state
        if (index === currentPage) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
    
    // Update previous button state
    const prevItem = pageItems[0];
    if (currentPage === 1) {
        prevItem.classList.add('disabled');
    } else {
        prevItem.classList.remove('disabled');
    }
    
    // Update next button state
    const nextItem = pageItems[pageItems.length - 1];
    if (currentPage === totalPages) {
        nextItem.classList.add('disabled');
    } else {
        nextItem.classList.remove('disabled');
    }
}


// guide_quiz.js
document.addEventListener('DOMContentLoaded', function() {
    const progressBar = document.getElementById('progress');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');

    let totalQuestions = 5; // Assuming 5 random questions
    let currentQuestionIndex = 0;

    // Update progress bar
    function updateProgressBar(index) {
        let percentage = ((index + 1) / totalQuestions) * 100;
        progressBar.style.width = percentage + '%';
    }

    // Listen to Next button click
    nextBtn.addEventListener('click', () => {
        currentQuestionIndex++;
        updateProgressBar(currentQuestionIndex);
    });

    // Listen to Previous button click
    prevBtn.addEventListener('click', () => {
        currentQuestionIndex--;
        updateProgressBar(currentQuestionIndex);
    });

    // Initial setup for progress bar
    updateProgressBar(currentQuestionIndex);
});


