import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  doc,
  deleteDoc,
  getDocs,
  getDoc,
  orderBy,
  query,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// DOM Elements
const form = document.getElementById("admin_announcement-form");
const titleInput = document.getElementById("admin_announcement-title");
const descInput = document.getElementById("admin_announcement-description");
const recipientSelect = document.getElementById("admin_announcement-recipientSelect");
const formSection = document.getElementById("admin_announcement-formSection");
const announcementList = document.getElementById("admin_announcement-list");
const deleteModal = document.getElementById("admin_announcement-deleteModal");
const confirmDeleteBtn = document.getElementById("admin_announcement-confirmDeleteBtn");
const cancelDeleteBtn = document.getElementById("admin_announcement-cancelDeleteBtn");
const addBtn = document.getElementById("admin_announcement-addBtn");

let currentEditId = null;
let announcementIdToDelete = null;

// Show form when Add button is clicked
addBtn.addEventListener("click", function() {
  document.getElementById("admin_announcement-formTitle").textContent = "Create New Announcement";
  form.reset();
  currentEditId = null;
  formSection.style.display = "block";
});

// Hide form when Cancel button is clicked
document.getElementById("admin_announcement-cancelBtn").addEventListener("click", function() {
  formSection.style.display = "none";
});

// Load park guides into dropdown
async function loadParkGuideOptions() {
  recipientSelect.innerHTML = ""; // Clear old options

  const allOption = document.createElement("option");
  allOption.value = "all";
  allOption.textContent = "All Park Guides";
  recipientSelect.appendChild(allOption);

  try {
    const snapshot = await getDocs(collection(db, "park_guides"));
    snapshot.forEach(doc => {
      const user = doc.data();
      const option = document.createElement("option");
      option.value = doc.id;
      option.textContent = user.name || user.email || "Unnamed Guide";
      recipientSelect.appendChild(option);
    });
  } catch (error) {
    console.error("Error loading park guides:", error);
  }
}

// Save (Create or Update) announcement
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const title = titleInput.value.trim();
  const description = descInput.value.trim();
  const recipient = recipientSelect.value;

  if (!title || !description) {
    alert("Please fill in both title and description.");
    return;
  }

  const data = {
    title,
    description,
    recipient,
    status: "pending", // default status added
    updatedAt: serverTimestamp()
  };

  try {
    if (currentEditId) {
      await updateDoc(doc(db, "announcements", currentEditId), data);
      currentEditId = null;
    } else {
      await addDoc(collection(db, "announcements"), {
        ...data,
        createdAt: serverTimestamp()
      });
    }

    form.reset();
    formSection.style.display = "none";
    await loadAnnouncements();
  } catch (error) {
    console.error("Error saving announcement:", error);
    alert("Failed to save announcement.");
  }
});

// Load announcements from Firestore with styled cards
async function loadAnnouncements() {
  announcementList.innerHTML = "";

  try {
    const q = query(collection(db, "announcements"), orderBy("createdAt", "desc"));
    const snapshot = await getDocs(q);
    const announcements = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    if (announcements.length === 0) {
      // Display a "no announcements" message
      announcementList.innerHTML = `
        <div class="admin_announcement-no-results">
          <div class="admin_announcement-no-results-icon">
            <i class="far fa-comment-alt"></i>
          </div>
          <h4 class="admin_announcement-no-results-text">No announcements found</h4>
          <p>Create your first announcement to get started</p>
        </div>
      `;
      return;
    }

    announcements.forEach(announcement => {
      const card = document.createElement("div");
      card.className = "admin_announcement-card";

      // Format recipient display
      let recipientDisplay = announcement.recipient === "all" ? 
        "All Park Guides" : 
        announcement.recipient;

      card.innerHTML = `
        <h4 class="admin_announcement-card-title">${announcement.title}</h4>
        <span class="admin_announcement-card-meta">Recipient: ${recipientDisplay}</span>
        <p class="admin_announcement-card-content">${announcement.description}</p>
        <div class="admin_announcement-card-actions">
          <button class="admin_announcement-btn-icon admin_announcement-btn-edit" onclick="firebaseAnnouncements.editAnnouncement('${announcement.id}')">
            <i class="fas fa-edit"></i>
          </button>
          <button class="admin_announcement-btn-icon admin_announcement-btn-delete" onclick="firebaseAnnouncements.showDeleteModal('${announcement.id}')">
            <i class="fas fa-trash-alt"></i>
          </button>
        </div>
      `;

      announcementList.appendChild(card);
    });
  } catch (error) {
    console.error("Error loading announcements:", error);
  }
}

// Edit an announcement
async function editAnnouncement(id) {
  try {
    const docRef = doc(db, "announcements", id);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      const data = docSnap.data();
      
      // Update form title
      document.getElementById("admin_announcement-formTitle").textContent = "Edit Announcement";
      
      // Populate form fields
      titleInput.value = data.title;
      descInput.value = data.description;
      recipientSelect.value = data.recipient;
      
      // Store the current announcement ID for update
      currentEditId = id;
      
      // Show the form
      formSection.style.display = "block";
      
      // Scroll to form
      formSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      alert("Announcement not found.");
    }
  } catch (error) {
    console.error("Error fetching announcement:", error);
  }
}

// Show the delete confirmation modal
function showDeleteModal(id) {
  announcementIdToDelete = id;
  deleteModal.classList.add("show");
}

// Hide delete modal
function hideDeleteModal() {
  deleteModal.classList.remove("show");
  announcementIdToDelete = null;
}

// Delete an announcement
async function deleteAnnouncement(id) {
  try {
    await deleteDoc(doc(db, "announcements", id));
    await loadAnnouncements();
  } catch (error) {
    console.error("Error deleting announcement:", error);
    alert("Failed to delete announcement. Please try again.");
  }
}

// Confirm delete button click
confirmDeleteBtn.addEventListener("click", async () => {
  if (announcementIdToDelete) {
    try {
      await deleteAnnouncement(announcementIdToDelete);
      hideDeleteModal();
    } catch (error) {
      console.error("Error deleting announcement:", error);
    }
  }
});

// Cancel delete button click
cancelDeleteBtn.addEventListener("click", () => {
  hideDeleteModal();
});

// Expose functions globally
window.firebaseAnnouncements = {
  loadAnnouncements,
  editAnnouncement,
  showDeleteModal
};

// Initial load
window.addEventListener("DOMContentLoaded", async () => {
  await loadParkGuideOptions();
  await loadAnnouncements();
});