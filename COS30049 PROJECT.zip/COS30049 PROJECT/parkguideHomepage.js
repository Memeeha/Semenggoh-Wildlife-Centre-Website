import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to update the badge count for announcements, guide courses, and certifications
async function updateBadgeCounts() {
  try {
    // Get the number of documents from each collection
    const announcementsSnapshot = await getDocs(collection(db, "announcements"));
    const guideCoursesSnapshot = await getDocs(collection(db, "guide_courses"));
    const certificationsSnapshot = await getDocs(collection(db, "certifications"));

    // Get the badge elements
    const announceBadge = document.getElementById("pg-announce-badge");
    const trainingBadge = document.getElementById("pg-training-badge");
    const certificatesBadge = document.getElementById("pg-certificates-badge");

    // Update the badges with the count from Firestore and show if count is > 0
    announceBadge.textContent = announcementsSnapshot.size;
    trainingBadge.textContent = guideCoursesSnapshot.size;
    certificatesBadge.textContent = certificationsSnapshot.size;

    // Show or hide badges based on count
    if (announcementsSnapshot.size > 0) {
      announceBadge.classList.add("visible");
    } else {
      announceBadge.classList.remove("visible");
    }

    if (guideCoursesSnapshot.size > 0) {
      trainingBadge.classList.add("visible");
    } else {
      trainingBadge.classList.remove("visible");
    }

    if (certificationsSnapshot.size > 0) {
      certificatesBadge.classList.add("visible");
    } else {
      certificatesBadge.classList.remove("visible");
    }
  } catch (error) {
    console.error("Error fetching badge counts:", error);
  }
}

// Call the function to update the badge counts when the page loads
window.onload = updateBadgeCounts;
