// park_guide_overview.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

function loadParkGuideOverviewRealtime() {
  const parkGuidesCol = collection(db, "park_guides");

  onSnapshot(parkGuidesCol, (snapshot) => {
    let activeCount = 0;
    let inactiveCount = 0;

    snapshot.forEach(doc => {
      const data = doc.data();
      const status = data.status?.toLowerCase();

      if (status === "active") {
        activeCount++;
      } else if (status === "inactive") {
        inactiveCount++;
      }
    });

    document.getElementById("activeGuidesCount").textContent = activeCount;
    document.getElementById("expiredCertsCount").textContent = inactiveCount;
  }, (error) => {
    console.error("Error loading park guide status:", error);
    document.getElementById("activeGuidesCount").textContent = "Error";
    document.getElementById("expiredCertsCount").textContent = "Error";
  });
}

loadParkGuideOverviewRealtime();
