
// Firebase SDK v10 imports
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, getDocs, updateDoc, doc, deleteDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Global variables
let currentDeleteId = null;
let allGuides = [];
let currentPage = 1;
let guidesPerPage = 10;

// Fetch and display park guide data
const loadParkGuides = async () => {
  const tableBody = document.getElementById("guidesTableBody");
  tableBody.innerHTML = "";
  
  try {
    const querySnapshot = await getDocs(collection(db, "park_guides"));
    
    if (querySnapshot.empty) {
      showNoRecordsMessage("No park guides found");
      updatePaginationInfo(0, 0, 0);
      return;
    }
    
    // Store all guides in memory
    allGuides = [];
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      allGuides.push({
        id: docSnap.id,
        ...data
      });
    });
    
    // Display guides with pagination
    displayGuides(allGuides);
    
  } catch (error) {
    console.error("Error loading park guides:", error);
    showNoRecordsMessage("Error loading park guides. Please try again later.");
    updatePaginationInfo(0, 0, 0);
  }
};

// Display guides with pagination and filtering
const displayGuides = (guides) => {
  const tableBody = document.getElementById("guidesTableBody");
  const noRecordsMessage = document.getElementById("noRecordsMessage");
  
  // Filter guides based on search
  const searchValue = document.getElementById("guideSearchInput")?.value.toLowerCase().trim() || "";
  const filteredGuides = guides.filter(guide => {
    return (
      (guide.fullName || "").toLowerCase().includes(searchValue) ||
      (guide.username || "").toLowerCase().includes(searchValue) ||
      (guide.email || "").toLowerCase().includes(searchValue) ||
      (guide.phone || "").toLowerCase().includes(searchValue) ||
      (guide.experience || "").toLowerCase().includes(searchValue) ||
      (guide.status || "").toLowerCase().includes(searchValue)
    );
  });
  
  // Show no records message if needed
  if (filteredGuides.length === 0) {
    showNoRecordsMessage(searchValue ? `No guides found matching "${searchValue}"` : "No park guides found");
    updatePaginationInfo(0, 0, 0);
    return;
  }
  
  // Hide no records message
  noRecordsMessage.style.display = "none";
  
  // Calculate pagination
  const totalGuides = filteredGuides.length;
  const totalPages = Math.ceil(totalGuides / guidesPerPage);
  
  // Ensure current page is valid
  if (currentPage > totalPages) {
    currentPage = totalPages;
  }
  
  const startIndex = (currentPage - 1) * guidesPerPage;
  const endIndex = Math.min(startIndex + guidesPerPage, totalGuides);
  const displayedGuides = filteredGuides.slice(startIndex, endIndex);
  
  // Update table with guides
  tableBody.innerHTML = "";
  displayedGuides.forEach((guide) => {
    const statusClass = guide.status === "active" ? "status-active" : "status-inactive";
    
    const toggleButton = guide.status === "active" 
      ? `<button class="guide-action-btn deactivate-btn" data-action="toggle" data-id="${guide.id}" data-status="${guide.status}">
          <i class="fas fa-ban"></i> Deactivate
         </button>`
      : `<button class="guide-action-btn activate-btn" data-action="toggle" data-id="${guide.id}" data-status="${guide.status}">
          <i class="fas fa-check-circle"></i> Activate
         </button>`;
    
    const row = `
      <tr>
        <td>${guide.fullName || '-'}</td>
        <td>${guide.username || '-'}</td>
        <td>${guide.email || '-'}</td>
        <td>${guide.phone || '-'}</td>
        <td>${guide.experience || '-'}</td>
        <td><span class="${statusClass}">${guide.status || 'undefined'}</span></td>
        <td>
          ${toggleButton}
          <button class="guide-action-btn delete-btn" data-action="delete" data-id="${guide.id}" data-name="${guide.fullName || 'Selected guide'}">
            <i class="fas fa-trash-alt"></i> Delete
          </button>
        </td>
      </tr>
    `;
    tableBody.innerHTML += row;
  });
  
  // Attach event listeners to action buttons
  attachActionButtonListeners();
  
  // Update pagination UI
  createPagination(totalPages);
  updatePaginationInfo(startIndex + 1, endIndex, totalGuides);
};

// Attach event listeners to dynamically created buttons
const attachActionButtonListeners = () => {
  // For toggle status buttons
  document.querySelectorAll('[data-action="toggle"]').forEach(button => {
    button.addEventListener('click', () => {
      const id = button.getAttribute('data-id');
      const status = button.getAttribute('data-status');
      toggleStatus(id, status);
    });
  });
  
  // For delete buttons
  document.querySelectorAll('[data-action="delete"]').forEach(button => {
    button.addEventListener('click', () => {
      const id = button.getAttribute('data-id');
      const name = button.getAttribute('data-name');
      showDeleteModal(id, name);
    });
  });
};

// Show no records message
const showNoRecordsMessage = (message) => {
  const tableBody = document.getElementById("guidesTableBody");
  const noRecordsMessage = document.getElementById("noRecordsMessage");
  
  tableBody.innerHTML = "";
  noRecordsMessage.textContent = message;
  noRecordsMessage.style.display = "block";
};

// Create pagination buttons
const createPagination = (totalPages) => {
  const paginationElement = document.getElementById("pagination");
  paginationElement.innerHTML = "";
  
  if (totalPages <= 1) {
    return;
  }
  
  // Previous button
  const prevBtn = document.createElement("button");
  prevBtn.className = "pg_basicinfo_pagination_btn";
  prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
  prevBtn.disabled = currentPage === 1;
  prevBtn.addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      displayGuides(allGuides);
    }
  });
  paginationElement.appendChild(prevBtn);
  
  // Page buttons
  let startPage = Math.max(1, currentPage - 2);
  let endPage = Math.min(totalPages, startPage + 4);
  
  // Adjust start if we're near the end
  if (endPage - startPage < 4) {
    startPage = Math.max(1, endPage - 4);
  }
  
  // First page button
  if (startPage > 1) {
    const firstBtn = document.createElement("button");
    firstBtn.className = "pg_basicinfo_pagination_btn";
    firstBtn.textContent = "1";
    firstBtn.addEventListener("click", () => {
      currentPage = 1;
      displayGuides(allGuides);
    });
    paginationElement.appendChild(firstBtn);
    
    if (startPage > 2) {
      const ellipsis = document.createElement("span");
      ellipsis.textContent = "...";
      ellipsis.className = "pg_basicinfo_pagination_ellipsis";
      paginationElement.appendChild(ellipsis);
    }
  }
  
  // Page number buttons
  for (let i = startPage; i <= endPage; i++) {
    const pageBtn = document.createElement("button");
    pageBtn.className = `pg_basicinfo_pagination_btn ${i === currentPage ? "pg_basicinfo_pagination_active" : ""}`;
    pageBtn.textContent = i;
    pageBtn.addEventListener("click", () => {
      currentPage = i;
      displayGuides(allGuides);
    });
    paginationElement.appendChild(pageBtn);
  }
  
  // Last page button
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      const ellipsis = document.createElement("span");
      ellipsis.textContent = "...";
      ellipsis.className = "pg_basicinfo_pagination_ellipsis";
      paginationElement.appendChild(ellipsis);
    }
    
    const lastBtn = document.createElement("button");
    lastBtn.className = "pg_basicinfo_pagination_btn";
    lastBtn.textContent = totalPages;
    lastBtn.addEventListener("click", () => {
      currentPage = totalPages;
      displayGuides(allGuides);
    });
    paginationElement.appendChild(lastBtn);
  }
  
  // Next button
  const nextBtn = document.createElement("button");
  nextBtn.className = "pg_basicinfo_pagination_btn";
  nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
  nextBtn.disabled = currentPage === totalPages;
  nextBtn.addEventListener("click", () => {
    if (currentPage < totalPages) {
      currentPage++;
      displayGuides(allGuides);
    }
  });
  paginationElement.appendChild(nextBtn);
};

// Update pagination information text
const updatePaginationInfo = (start, end, total) => {
  const startCount = document.getElementById("startCount");
  const endCount = document.getElementById("endCount");
  const totalCount = document.getElementById("totalCount");
  
  startCount.textContent = total > 0 ? start : 0;
  endCount.textContent = end;
  totalCount.textContent = total;
};

// Toggle guide status between active and inactive
const toggleStatus = async (id, currentStatus) => {
  try {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    const guideRef = doc(db, "park_guides", id);
    await updateDoc(guideRef, { status: newStatus });
    
    // Update local data
    const guideIndex = allGuides.findIndex(guide => guide.id === id);
    if (guideIndex !== -1) {
      allGuides[guideIndex].status = newStatus;
      displayGuides(allGuides);
    } else {
      // Reload all data if guide not found locally
      loadParkGuides();
    }
  } catch (error) {
    console.error("Error toggling status:", error);
    alert("Failed to update guide status. Please try again.");
  }
};

// Show delete confirmation modal
const showDeleteModal = (id, guideName) => {
  currentDeleteId = id;
  
  // Set the guide name in the modal
  document.getElementById('deleteGuideName').textContent = guideName || 'Selected guide';
  
  // Show the modal
  const modal = document.getElementById('deleteModal');
  modal.style.display = 'flex';
};

// Delete guide function
const deleteGuide = async () => {
  if (currentDeleteId) {
    try {
      await deleteDoc(doc(db, "park_guides", currentDeleteId));
      
      // Update local data
      allGuides = allGuides.filter(guide => guide.id !== currentDeleteId);
      
      document.getElementById('deleteModal').style.display = 'none';
      currentDeleteId = null;
      
      // Recalculate pagination if needed
      const totalPages = Math.ceil(allGuides.length / guidesPerPage);
      if (currentPage > totalPages && totalPages > 0) {
        currentPage = totalPages;
      }
      
      displayGuides(allGuides);
    } catch (error) {
      console.error("Error deleting guide:", error);
      alert("Failed to delete guide. Please try again.");
    }
  }
};

// Setup records per page selector
const setupRecordsPerPage = () => {
  const recordsPerPage = document.getElementById('recordsPerPage');
  if (recordsPerPage) {
    recordsPerPage.value = guidesPerPage.toString(); // Set initial value
    recordsPerPage.addEventListener('change', () => {
      guidesPerPage = parseInt(recordsPerPage.value);
      currentPage = 1; // Reset to first page
      displayGuides(allGuides);
    });
  }
};

// Search logic
const performSearch = () => {
  const searchValue = document.getElementById('guideSearchInput').value.toLowerCase().trim();
  const rows = document.querySelectorAll('#guidesTableBody tr');
  
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(searchValue) ? '' : 'none';
  });
  
  // Show no results message if needed
  const visibleRows = [...rows].filter(row => row.style.display !== 'none');
  if (visibleRows.length === 0 && searchValue !== '') {
    const tableBody = document.getElementById('guidesTableBody');
    // Check if we already have a no results row
    if (!document.querySelector('.no-results-row')) {
      tableBody.innerHTML += `
        <tr class="no-results-row">
          <td colspan="7" class="pg_basicinfo_no_records">No guides found matching "${searchValue}"</td>
        </tr>
      `;
    }
  } else {
    // Remove any existing no results row
    const noResultsRow = document.querySelector('.no-results-row');
    if (noResultsRow) {
      noResultsRow.remove();
    }
  }
};

// Document ready function
document.addEventListener('DOMContentLoaded', () => {
  // Load park guides data
  loadParkGuides();
  
  // Setup search functionality
  const searchInput = document.getElementById('guideSearchInput');
  if (searchInput) {
    searchInput.addEventListener('input', performSearch);
    
    // Add clear search button functionality
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    if (clearSearchBtn) {
      clearSearchBtn.addEventListener('click', () => {
        searchInput.value = '';
        performSearch();
      });
    }
  }
  
  // Setup records per page selector
  setupRecordsPerPage();
  
  // Set up modal event listeners
  document.getElementById('cancelDelete').addEventListener('click', () => {
    document.getElementById('deleteModal').style.display = 'none';
    currentDeleteId = null;
  });

  document.getElementById('confirmDelete').addEventListener('click', deleteGuide);
  
  // Close modal when clicking outside of it
  document.getElementById('deleteModal').addEventListener('click', (event) => {
    if (event.target === document.getElementById('deleteModal')) {
      document.getElementById('deleteModal').style.display = 'none';
      currentDeleteId = null;
    }
  });
});