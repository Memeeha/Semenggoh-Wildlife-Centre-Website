import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  query,
  where,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  addDoc,
  getDoc,
  orderBy,
  limit,
  startAfter,
  endBefore,
  limitToLast
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// EmailJS configuration
const EMAILJS_SERVICE_ID = "service_us1byu4";
const EMAILJS_APPROVAL_TEMPLATE_ID = "template_ocm4kdx";
const EMAILJS_PUBLIC_KEY = "zUGDJ6tyI0F2Ipr40";

// Initialize EmailJS
emailjs.init(EMAILJS_PUBLIC_KEY);

// State management
let allGuides = [];
let filteredGuides = [];
let currentPage = 1;
const guidesPerPage = 6;
let lastVisibleDoc = null;
let firstVisibleDoc = null;

// DOM elements
const searchInput = document.getElementById('adminapproval_search_input');
const guideGrid = document.getElementById('adminapproval_guide_grid');
const loadingDiv = document.getElementById('adminapproval_loading');
const pendingCountSpan = document.getElementById('adminapproval_pending_count');
const totalCountSpan = document.getElementById('adminapproval_total_count');
const paginationInfo = document.getElementById('adminapproval_pagination_info');
const prevBtn = document.getElementById('adminapproval_prev_btn');
const nextBtn = document.getElementById('adminapproval_next_btn');

// Utility functions
function showLoading() {
  if (loadingDiv) {
    loadingDiv.style.display = 'flex';
  }
  if (guideGrid) {
    guideGrid.style.display = 'none';
  }
}

function hideLoading() {
  if (loadingDiv) {
    loadingDiv.style.display = 'none';
  }
  if (guideGrid) {
    guideGrid.style.display = 'grid';
  }
}

function getInitials(name) {
  if (!name) return 'UN';
  return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
}

function formatDate(dateString) {
  if (!dateString) return 'Not specified';
  
  // Handle Firestore Timestamp objects
  if (dateString && typeof dateString.toDate === 'function') {
    return dateString.toDate().toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  }
  
  // Handle regular date strings
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return 'Invalid date';
  
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

function formatLanguages(languages) {
  if (!languages || languages.length === 0) return ['Not specified'];
  return Array.isArray(languages) ? languages : [languages];
}

// Load pending guides from Firebase
async function loadPendingGuides() {
  try {
    console.log("Starting to load pending guides...");
    showLoading();
    
    // Try different possible collection names
    const possibleCollections = ["park_guides", "parkGuides", "guides"];
    let querySnapshot = null;
    let usedCollection = null;
    
    for (const collectionName of possibleCollections) {
      try {
        console.log(`Trying collection: ${collectionName}`);
        
        // First, try to get all documents to see if collection exists
        const testQuery = query(collection(db, collectionName));
        const testSnapshot = await getDocs(testQuery);
        
        if (!testSnapshot.empty) {
          console.log(`Found collection: ${collectionName} with ${testSnapshot.size} documents`);
          
          // Now get pending guides
          const q = query(
            collection(db, collectionName), 
            where("approved", "==", false),
            orderBy("createdAt", "desc")
          );
          
          querySnapshot = await getDocs(q);
          usedCollection = collectionName;
          console.log(`Found ${querySnapshot.size} pending guides in ${collectionName}`);
          break;
        }
      } catch (error) {
        console.log(`Collection ${collectionName} not found or error:`, error.message);
        continue;
      }
    }
    
    if (!querySnapshot) {
      throw new Error("Could not find park guides collection. Check your Firebase collection name.");
    }
    
    allGuides = [];
    
    querySnapshot.forEach((docSnap) => {
      const data = docSnap.data();
      console.log("Guide data:", data); // Debug log
      
      allGuides.push({
        id: docSnap.id,
        fullName: data.fullName || data.full_name || data.name || 'Unknown Name',
        email: data.email || 'No email',
        username: data.username || 'Not specified',
        phone: data.phone || 'Not specified',
        dob: data.dob || data.dateOfBirth,
        employmentDate: data.employmentDate || data.employment_date,
        experience: data.experience || 0,
        specialties: data.specialties || data.expertise || '',
        languages: data.languages || [],
        approved: data.approved || false,
        createdAt: data.createdAt,
        status: data.status || 'pending',
        ...data // Include all other fields
      });
    });
    
    console.log(`Loaded ${allGuides.length} guides:`, allGuides);
    
    filteredGuides = [...allGuides];
    updateStats();
    renderGuides();
    setupPagination();
    
  } catch (error) {
    console.error("Error loading guides:", error);
    showNoResults(`Error loading guides: ${error.message}. Please check the console and refresh the page.`);
  } finally {
    hideLoading();
  }
}

// Update statistics
function updateStats() {
  if (pendingCountSpan) {
    pendingCountSpan.textContent = filteredGuides.length;
  }
  if (totalCountSpan) {
    totalCountSpan.textContent = allGuides.length;
  }
}

// Render guides for current page
function renderGuides() {
  if (!guideGrid) {
    console.error("Guide grid element not found");
    return;
  }
  
  const startIndex = (currentPage - 1) * guidesPerPage;
  const endIndex = startIndex + guidesPerPage;
  const guidesToShow = filteredGuides.slice(startIndex, endIndex);
  
  if (guidesToShow.length === 0) {
    showNoResults();
    return;
  }
  
  guideGrid.innerHTML = '';
  
  guidesToShow.forEach(guide => {
    const guideCard = createGuideCard(guide);
    guideGrid.appendChild(guideCard);
  });
  
  updatePaginationInfo();
}

// Create guide card element
function createGuideCard(guide) {
  const card = document.createElement('div');
  card.className = 'adminapproval_guide_card';
  
  const languages = formatLanguages(guide.languages);
  
  card.innerHTML = `
    <div class="adminapproval_guide_header">
      <div class="adminapproval_guide_avatar">
        ${getInitials(guide.fullName)}
      </div>
      <div>
        <h3 class="adminapproval_guide_name">${guide.fullName || 'Unknown Name'}</h3>
        <p class="adminapproval_guide_email">${guide.email || 'No email'}</p>
      </div>
    </div>
    
    <div class="adminapproval_guide_details">
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Username</span>
        <span class="adminapproval_detail_value">${guide.username || 'Not specified'}</span>
      </div>
      
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Phone</span>
        <span class="adminapproval_detail_value">${guide.phone || 'Not specified'}</span>
      </div>
      
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Date of Birth</span>
        <span class="adminapproval_detail_value">${formatDate(guide.dob)}</span>
      </div>
      
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Employment Date</span>
        <span class="adminapproval_detail_value">${formatDate(guide.employmentDate)}</span>
      </div>
      
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Experience</span>
        <span class="adminapproval_detail_value">
          ${guide.experience || 0} year${(guide.experience || 0) !== 1 ? 's' : ''}
        </span>
      </div>
      
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Applied</span>
        <span class="adminapproval_detail_value">
          ${guide.createdAt ? formatDate(guide.createdAt) : 'Unknown'}
        </span>
      </div>
      
      <div class="adminapproval_detail_item">
        <span class="adminapproval_detail_label">Status</span>
        <span class="adminapproval_detail_value">${guide.status || 'Pending'}</span>
      </div>
    </div>
    
    ${guide.specialties ? `
      <div class="adminapproval_specialties">
        <span class="adminapproval_detail_label">Specialties & Expertise</span>
        <div class="adminapproval_detail_value">${guide.specialties}</div>
      </div>
    ` : ''}
    
    <div class="adminapproval_detail_item" style="margin-bottom: 1rem;">
      <span class="adminapproval_detail_label">Languages</span>
      <div class="adminapproval_languages">
        ${languages.map(lang => `
          <span class="adminapproval_language_tag">${lang}</span>
        `).join('')}
      </div>
    </div>
    
    <div class="adminapproval_actions">
      <button class="adminapproval_btn adminapproval_approve_btn" 
              data-id="${guide.id}" 
              data-email="${guide.email}" 
              data-name="${guide.fullName}">
        <i class="fas fa-check"></i> Approve
      </button>
      <button class="adminapproval_btn adminapproval_delete_btn" 
              data-id="${guide.id}">
        <i class="fas fa-trash"></i> Delete
      </button>
    </div>
  `;
  
  // Add event listeners
  const approveBtn = card.querySelector('.adminapproval_approve_btn');
  const deleteBtn = card.querySelector('.adminapproval_delete_btn');
  
  if (approveBtn) {
    approveBtn.addEventListener('click', () => handleApproval(guide));
  }
  if (deleteBtn) {
    deleteBtn.addEventListener('click', () => handleDeletion(guide));
  }
  
  return card;
}

// Handle guide approval
async function handleApproval(guide) {
  if (!confirm(`Are you sure you want to approve ${guide.fullName}?`)) {
    return;
  }
  
  try {
    const guideRef = doc(db, "park_guides", guide.id);
    
    // Check if guide still exists
    const guideSnapshot = await getDoc(guideRef);
    if (!guideSnapshot.exists()) {
      throw new Error("Guide data not found");
    }
    
    const guideData = guideSnapshot.data();
    
    // 1. Update approval status
    await updateDoc(guideRef, { 
      approved: true,
      status: "approved"
    });
    
    // 2. Issue certification
    const certificateIssueDate = new Date().toISOString().split("T")[0];
    const certificateExpiryDate = "2026-12-31";
    
    await addDoc(collection(db, "certification_renewal"), {
      email: guideData.email,
      certificateTitle: "Park Guide Certificate",
      issueDate: certificateIssueDate,
      expiryDate: certificateExpiryDate,
      status: "Approved",
    });
    
    // 3. Send approval email using EmailJS
    try {
      const emailParams = {
        email: guideData.email,
        name: guideData.fullName || guideData.full_name,
        issue_date: certificateIssueDate,
        expiry_date: certificateExpiryDate,
        role: "Park Guide",
        login_url: "https://yourdomain.com/login.html",
        homepage: "https://yourdomain.com/parkGuideHomepage.html"
      };
      
      console.log("Sending approval email with params:", emailParams);
      
      const response = await emailjs.send(
        EMAILJS_SERVICE_ID,
        EMAILJS_APPROVAL_TEMPLATE_ID,
        emailParams
      );
      
      console.log("EmailJS response:", response);
      alert(`${guide.fullName} has been approved successfully! Certification issued and notification email sent.`);
      
    } catch (emailError) {
      console.error("EmailJS sending failed:", emailError);
      const errorMessage = emailError?.text || emailError?.message || JSON.stringify(emailError);
      alert(`${guide.fullName} has been approved and certification issued, but email failed to send:\n${errorMessage}`);
    }
    
    // Refresh the page data
    await loadPendingGuides();
    
  } catch (error) {
    console.error("Approval process error:", error);
    alert(`Something went wrong while approving ${guide.fullName}:\n${error.message}`);
  }
}

// Handle guide deletion
async function handleDeletion(guide) {
  if (!confirm(`Are you sure you want to delete ${guide.fullName}'s application? This action cannot be undone.`)) {
    return;
  }
  
  try {
    await deleteDoc(doc(db, "park_guides", guide.id));
    alert(`${guide.fullName}'s application has been deleted.`);
    
    // Refresh the page data
    await loadPendingGuides();
    
  } catch (error) {
    console.error("Error deleting guide:", error);
    alert(`Failed to delete ${guide.fullName}'s application.`);
  }
}

// Search functionality
function handleSearch() {
  if (!searchInput) return;
  
  const searchTerm = searchInput.value.toLowerCase().trim();
  
  if (!searchTerm) {
    filteredGuides = [...allGuides];
  } else {
    filteredGuides = allGuides.filter(guide => {
      const searchFields = [
        guide.fullName,
        guide.email,
        guide.username,
        guide.phone,
        guide.specialties,
        ...(guide.languages || [])
      ];
      
      return searchFields.some(field => 
        field && field.toString().toLowerCase().includes(searchTerm)
      );
    });
  }
  
  currentPage = 1;
  updateStats();
  renderGuides();
  setupPagination();
}

// Pagination setup
function setupPagination() {
  const totalPages = Math.ceil(filteredGuides.length / guidesPerPage);
  
  if (prevBtn) {
    prevBtn.disabled = currentPage <= 1;
    prevBtn.onclick = () => {
      if (currentPage > 1) {
        currentPage--;
        renderGuides();
        setupPagination();
      }
    };
  }
  
  if (nextBtn) {
    nextBtn.disabled = currentPage >= totalPages;
    nextBtn.onclick = () => {
      const totalPages = Math.ceil(filteredGuides.length / guidesPerPage);
      if (currentPage < totalPages) {
        currentPage++;
        renderGuides();
        setupPagination();
      }
    };
  }
}

// Update pagination info
function updatePaginationInfo() {
  if (paginationInfo) {
    const totalPages = Math.ceil(filteredGuides.length / guidesPerPage);
    paginationInfo.textContent = `Page ${currentPage} of ${totalPages}`;
  }
}

// Show no results message
function showNoResults(message = "No pending applications found.") {
  if (guideGrid) {
    guideGrid.innerHTML = `
      <div class="adminapproval_no_results">
        <i class="fas fa-users adminapproval_no_results_icon"></i>
        <p class="adminapproval_no_results_text">${message}</p>
      </div>
    `;
  }
}

// Event listeners
if (searchInput) {
  searchInput.addEventListener('input', handleSearch);
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  });
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
  console.log("DOM loaded, initializing...");
  loadPendingGuides();
});

// Auto-refresh every 30 seconds
setInterval(loadPendingGuides, 30000);
// Handle back button navigation
window.addEventListener('popstate', () => {
  console.log("Back button pressed, reloading guides...");
  loadPendingGuides();
});
