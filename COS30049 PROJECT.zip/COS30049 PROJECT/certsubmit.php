<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = 'uploads/';
    $uploadedFiles = [];

    foreach ($_FILES['cert_files']['name'] as $key => $name) {
        $tmpName = $_FILES['cert_files']['tmp_name'][$key];
        $targetPath = $uploadDir . basename($name);

        if (move_uploaded_file($tmpName, $targetPath)) {
            $uploadedFiles[] = 'http://localhost/Firebase%20new/' . $targetPath;
        }
    }

    echo json_encode([
        'success' => true,
        'fileURLs' => $uploadedFiles
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>
