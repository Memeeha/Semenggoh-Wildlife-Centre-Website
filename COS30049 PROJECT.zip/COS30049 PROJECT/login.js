import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// EmailJS configuration
const EMAILJS_SERVICE_ID = "service_us1byu4";
const EMAILJS_TEMPLATE_ID = "template_7vvuje8";
const EMAILJS_PUBLIC_KEY = "zUGDJ6tyI0F2Ipr40";

// Initialize EmailJS
emailjs.init(EMAILJS_PUBLIC_KEY);

// DOM Elements
const sendOtpBtn = document.getElementById("sendOtpBtn");
const loginForm = document.getElementById("loginForm");
const loginBtn = document.getElementById("loginBtn");
const otpSection = document.getElementById("otpSection");

let currentUid = null;
let otpSent = false;

// reCAPTCHA v2 validation function
function validateRecaptcha() {
  const recaptchaResponse = grecaptcha.getResponse();
  if (recaptchaResponse.length === 0) {
    alert("Please complete the reCAPTCHA verification.");
    return false;
  }
  return true;
}

// Step 1: Send OTP
sendOtpBtn.addEventListener("click", async () => {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  if (!email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  // Validate reCAPTCHA
  if (!validateRecaptcha()) {
    return;
  }

  try {
    console.log("Attempting to send OTP to:", email);

    // Firebase sign-in
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    const uid = userCredential.user.uid;
    currentUid = uid;

    // Check if user has a park guide profile
    const guideDoc = await getDoc(doc(db, "park_guides", uid));

    if (!guideDoc.exists()) {
      alert("No user profile found. Please contact admin.");
      return;
    }

    const guideData = guideDoc.data();

    // Important: Check if the account has been approved by an admin
    if (!guideData.approved) {
      alert("Your account is pending admin approval. Please wait for an administrator to approve your account.");
      return;
    }
    
    console.log("✅ Account approval status:", guideData.approved ? "Approved" : "Not Approved");

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 15 * 60 * 1000; // 15 minutes
    const expiryTime = new Date(expiresAt).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    });

    // Save OTP to Firestore
    await setDoc(doc(db, "guideOtps", uid), { otp, expiresAt });

    // Create EmailJS parameters to match your template
    const emailParams = {
      email: email,          // This matches {{email}} in your template
      passcode: otp,         // This matches {{passcode}} in your template
      time: expiryTime       // This matches {{time}} in your template
    };
    
    console.log("Sending EmailJS with params:", emailParams);
    
    // Send OTP via EmailJS
    const response = await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, emailParams);
    console.log("EmailJS response:", response);

    // Show OTP input section
    otpSection.style.display = "block";
    loginBtn.style.display = "inline-block";
    sendOtpBtn.disabled = true;
    otpSent = true;

    alert("OTP sent to your email. Please check and enter it to proceed.");
  } catch (error) {
    console.error("Send OTP Error:", error);
    alert("Failed to send OTP email: " + (error.text || error.message));
  }
});

// Step 2: Verify OTP and complete login
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const enteredOtp = document.getElementById("otp").value.trim();

  // Validate reCAPTCHA again for final login
  if (!validateRecaptcha()) {
    return;
  }

  if (!otpSent || !currentUid) {
    alert("Please request an OTP first.");
    return;
  }

  try {
    const otpDoc = await getDoc(doc(db, "guideOtps", currentUid));
    if (!otpDoc.exists()) {
      alert("OTP not found. Please request a new one.");
      return;
    }

    const { otp, expiresAt } = otpDoc.data();

    if (Date.now() > expiresAt) {
      alert("OTP expired. Please request a new one.");
      document.getElementById("otp").value = "";
      return;
    }

    if (enteredOtp !== otp) {
      alert("Invalid OTP. Please try again.");
      document.getElementById("otp").value = "";
      return;
    }

    // ✅ Log successful login
    console.log("🔐 Logged in as:", document.getElementById("email").value);
    console.log("🆔 UID:", currentUid);

    alert("Login successful!");
    window.location.href = "parkGuideHomepage.html";
  } catch (error) {
    console.error("OTP Verification Error:", error);
    alert("Login failed: " + error.message);
  }
});