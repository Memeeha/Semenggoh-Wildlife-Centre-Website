import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { getFirestore, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// DOM element
const certificationsContainer = document.getElementById("certificationsContainer");

// Helper to generate uploaded file links
function createFileLinks(files) {
  if (!files || files.length === 0) {
    return "<p>No files uploaded.</p>";
  }
  return files.map((url, index) => 
    `<p><a href="${url}" target="_blank">View File ${index + 1}</a></p>`
  ).join("");
}

// Auth check and data load
onAuthStateChanged(auth, async (user) => {
  console.log("Auth state changed:", user);

  if (!user) {
    certificationsContainer.innerHTML = "<p>Please log in to view your certifications.</p>";
    return;
  }

  const userEmail = user.email;
  console.log("Logged in as:", userEmail);

  try {
    const certQuery = query(
      collection(db, "certification_renewal"),
      where("email", "==", userEmail)
    );

    const snapshot = await getDocs(certQuery);
    console.log("Certifications found:", snapshot.size);

    if (snapshot.empty) {
      certificationsContainer.innerHTML = "<p>No certifications found for your account.</p>";
      return;
    }

    snapshot.forEach((doc) => {
      const cert = doc.data();

      const card = document.createElement("div");
      card.className = "pg-certification-card";

      card.innerHTML = `
        <h4>${cert.certifications || "Untitled Certificate"}</h4>
        <p><strong>Guide Name:</strong> ${cert.fullName || "Unknown"}</p>
        <p><strong>Issued:</strong> ${cert.timestamp?.toDate().toDateString() || "N/A"}</p>
        <p><strong>Expiry:</strong> ${cert.certExpiry || "N/A"}</p>
        <p><strong>Status:</strong> ${cert.status || "Unknown"}</p>
        <p><strong>Test Marks:</strong> ${cert.testMarks || "N/A"}</p>
        <div><strong>Uploaded Files:</strong>${createFileLinks(cert.uploadedFiles)}</div>
      `;

      certificationsContainer.appendChild(card);
    });
  } catch (error) {
    console.error("Error loading certifications:", error);
    certificationsContainer.innerHTML = "<p>Failed to load certifications. Please try again later.</p>";
  }
});
