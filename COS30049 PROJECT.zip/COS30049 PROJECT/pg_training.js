import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  query,
  where,
  getDocs
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import {
  getAuth,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const trainingsContainer = document.getElementById("trainingsContainer");
const noTrainingMsg = document.getElementById("noTrainingMessage");

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    noTrainingMsg.textContent = "Please log in to view your assigned trainings.";
    trainingsContainer.innerHTML = ""; // clear container
    return;
  }

  const userEmail = user.email;

  try {
    // Step 1: Map email to username via park_guides collection
    const guideQuery = query(collection(db, "park_guides"), where("email", "==", userEmail));
    const guideSnapshot = await getDocs(guideQuery);

    if (guideSnapshot.empty) {
      noTrainingMsg.textContent = "Your account is not linked to any park guide profile.";
      trainingsContainer.innerHTML = "";
      return;
    }

    const username = guideSnapshot.docs[0].data().username;
    console.log("Found username for current user:", username);

    // Step 2: Fetch guide_courses assigned to that username
    const courseQuery = query(collection(db, "guide_courses"), where("username", "==", username));
    const courseSnapshot = await getDocs(courseQuery);

    trainingsContainer.innerHTML = ""; // clear old content
    noTrainingMsg.textContent = ""; // clear message

    if (courseSnapshot.empty) {
      noTrainingMsg.textContent = "You have not been assigned any courses yet.";
      return;
    }

    courseSnapshot.forEach(doc => {
      const data = doc.data();

      const card = document.createElement("div");
      card.className = "pg-training-card";
      card.innerHTML = `
        <h4>${data.course_name || "No course name"}</h4>
        <p><strong>Description:</strong> ${data.description || "No description available"}</p>
        <p><strong>Date:</strong> ${data.training_date || "N/A"}</p>
        <p><strong>Status:</strong> ${data.training_status || "N/A"}</p>
      `;

      trainingsContainer.appendChild(card);
    });

  } catch (err) {
    console.error("Error fetching assigned trainings:", err);
    noTrainingMsg.textContent = "Failed to load assigned trainings.";
    trainingsContainer.innerHTML = "";
  }
});
