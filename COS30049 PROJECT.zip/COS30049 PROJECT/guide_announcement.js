// guide_announcement.js

import { firebaseConfig } from "./firebase-config.js";
import { initializeApp, getApps } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection,
  query,
  orderBy,
  onSnapshot
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

// Initialize Firebase only if it hasn't been initialized yet
if (!getApps().length) {
  initializeApp(firebaseConfig);
}

const db = getFirestore();

function displayAnnouncements() {
  const container = document.getElementById("announcementsContainer");
  if (!container) return;

  // Set up query to get announcements ordered by createdAt
  const announcementsQuery = query(
    collection(db, "announcements"),
    orderBy("createdAt", "desc")
  );

  // Real-time listener for announcements
  onSnapshot(
    announcementsQuery,
    (snapshot) => {
      container.innerHTML = ""; // Clear previous content

      if (snapshot.empty) {
        container.innerHTML = "<p>No announcements found.</p>";
        return;
      }

      snapshot.forEach((doc) => {
        const data = doc.data();

        const card = document.createElement("div");
        card.className = "pg-announcement-card";

        const title = document.createElement("h4");
        title.textContent = data.title || "Untitled";

        const description = document.createElement("p");
        description.textContent = data.description || "No description available.";

        const createdAt = document.createElement("small");
        if (data.createdAt && data.createdAt.toDate) {
          const dateStr = data.createdAt.toDate().toLocaleString();
          createdAt.textContent = `Posted on: ${dateStr}`;
        } else {
          createdAt.textContent = "Date unknown";
        }

        card.appendChild(title);
        card.appendChild(description);
        card.appendChild(createdAt);

        container.appendChild(card);
      });
    },
    (error) => {
      console.error("Error loading announcements:", error);
      container.innerHTML = "<p>Error loading announcements. Please try again later.</p>";
    }
  );
}

// Wait until DOM is ready
document.addEventListener("DOMContentLoaded", displayAnnouncements);
