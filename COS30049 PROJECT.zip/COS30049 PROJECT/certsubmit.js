import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const form = document.getElementById('certForm');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const fullName = document.getElementById('full_name').value;
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const testMarks = document.getElementById('test_marks').value;
  const certifications = document.getElementById('certifications').value;
  const certExpiry = document.getElementById('cert_expiry').value;
  const certFiles = document.getElementById('cert_files').files;

  const formData = new FormData();
  for (let file of certFiles) {
    formData.append('cert_files[]', file); // Use [] for PHP multiple files
  }

  try {
    // 1. Upload files via PHP
    const uploadResponse = await fetch('certsubmit.php', {
      method: 'POST',
      body: formData
    });

    const resultText = await uploadResponse.text();
    console.log("Raw PHP response:", resultText);

    const result = JSON.parse(resultText);

    if (!result.success) {
      throw new Error("File upload failed");
    }

    // 2. Save info + file URLs to Firebase
    await addDoc(collection(db, "certification_renewal"), {
      fullName,
      username,
      email,
      testMarks,
      certifications,
      certExpiry,
      uploadedFiles: result.fileURLs,  // list of URLs from PHP
      timestamp: new Date()
    });

    alert("Form submitted successfully!");
    form.reset();
  } catch (error) {
    console.error("Submission error:", error);
    alert("Submission failed: " + error.message);
  }
});
