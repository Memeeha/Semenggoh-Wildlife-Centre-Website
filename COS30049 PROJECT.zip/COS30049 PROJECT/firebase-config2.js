// Firebase v8 config
export const firebaseConfig = {
  apiKey: "AIzaSyDx5Zx5wG0xKfWvLXfXx2X9jkc-fcHa-H0",
  authDomain: "test-9d9ca.firebaseapp.com",
  databaseURL: "https://test-9d9ca-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "test-9d9ca",
  storageBucket: "test-9d9ca.firebasestorage.app",
  messagingSenderId: "84555163784",
  appId: "1:84555163784:web:14c0267fb44e3671fa173d",
  measurementId: "G-XGMP3PJJK8"
};