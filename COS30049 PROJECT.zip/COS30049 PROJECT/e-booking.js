// Initialize Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js"; // Import Firebase config

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// EmailJS Configuration
const EMAILJS_SERVICE_ID = "service_g879d44";
const EMAILJS_TEMPLATE_ID = "template_8ktq81p";
const EMAILJS_PUBLIC_KEY = "V0jsFo9EKw08ED0cs";

// Initialize EmailJS with the new syntax
emailjs.init({
    publicKey: EMAILJS_PUBLIC_KEY
});

// Fetch Guide Data from Firebase and Populate Table
window.onload = async function () {
    console.log("=== STARTING GUIDE DATA FETCH ===");
    const guideTableBody = document.querySelector('.ebooking-table tbody');
    
    if (!guideTableBody) {
        console.error("ERROR: Could not find table body element");
        return;
    }
    
    try {
        console.log("Fetching guide data from Firestore...");
        
        // Query the park_guides collection
        const querySnapshot = await getDocs(collection(db, "park_guides"));
        console.log("Query Snapshot fetched:", querySnapshot);
        console.log("Number of documents:", querySnapshot.size);
        
        if (querySnapshot.empty) {
            console.log("No guides found in Firestore");
            return;
        }

        // Clear existing table content first
        guideTableBody.innerHTML = '';

        // Iterate over the fetched data
        querySnapshot.forEach((doc, index) => {
            const guideData = doc.data();
            console.log(`=== Guide ${index + 1} Data ===`);
            console.log("Full guide data:", guideData);
            console.log("Guide name:", guideData.fullName);
            console.log("Guide email:", guideData.email);
            console.log("Email type:", typeof guideData.email);
            console.log("Email length:", guideData.email ? guideData.email.length : 'undefined');

            // Ensure email exists and is not empty
            const guideEmail = guideData.email || '';
            const guideName = guideData.fullName || 'Unknown Guide';
            
            console.log("Processed email:", guideEmail);
            console.log("Processed name:", guideName);

            // Create a table row for each guide
            const row = document.createElement("tr");

            // Create the button HTML with proper escaping
            const emailButtonHTML = `
                <button class="btn btn-email" onclick="window.openEmailModal('${guideName.replace(/'/g, "\\'")}', '${guideEmail.replace(/'/g, "\\'")}')">
                    <i class="fas fa-envelope"></i> Email
                </button>
            `;

            row.innerHTML = `
                <td><strong>${index + 1}</strong></td>
                <td>
                    <div class="guide-name">${guideName}</div>
                </td>
                <td class="guide-hours">
                    <strong>Mon-Thu:</strong> 8:00am - 1:00pm & 2:00pm - 5:00pm<br>
                    <strong>Friday:</strong> 8:00am - 11:45am & 2:15pm - 5:00pm
                </td>
                <td>
                    <div class="guide-actions">
                        ${emailButtonHTML}
                        <button class="btn btn-info" onclick="showGuideInfo('${guideName.replace(/'/g, "\\'")}')">
                            <i class="fas fa-info-circle"></i> Info
                        </button>
                    </div>
                </td>
            `;
            
            console.log("Adding row to table for:", guideName);
            guideTableBody.appendChild(row);
        });
        
        console.log("=== TABLE POPULATION COMPLETE ===");
    } catch (error) {
        console.error("Error fetching guide data: ", error);
        console.error("Error details:", error.message);
        console.error("Error stack:", error.stack);
    }
};

// Open Email Modal and prefill guide details
window.openEmailModal = function(guideName, guideEmail) {
    console.log("=== OPENING EMAIL MODAL ===");
    console.log('Function called with parameters:');
    console.log('- Guide Name:', guideName);
    console.log('- Guide Email:', guideEmail);
    console.log('- Email type:', typeof guideEmail);
    console.log('- Email length:', guideEmail ? guideEmail.length : 'undefined/null');
    
    // Check if email is provided and not empty
    if (!guideEmail || guideEmail.trim() === '') {
        console.error('ERROR: Guide email is empty or undefined');
        alert('Error: Guide email is not available. Please contact the administrator.');
        return;
    }
    
    // Get the form elements
    const guideNameField = document.getElementById('guideName');
    const guideEmailField = document.getElementById('guideEmail');
    const modal = document.getElementById('emailModal');
    
    if (!guideNameField || !guideEmailField || !modal) {
        console.error('ERROR: Required form elements not found');
        console.log('guideName field:', guideNameField);
        console.log('guideEmail field:', guideEmailField);
        console.log('modal:', modal);
        return;
    }
    
    // Set the values
    guideNameField.value = guideName;
    guideEmailField.value = guideEmail.trim();
    
    console.log('Form fields set:');
    console.log('- Name field value:', guideNameField.value);
    console.log('- Email field value:', guideEmailField.value);
    
    // Show the modal
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    console.log('Modal opened successfully');
}

// Close Email Modal
window.closeEmailModal = function() {
    console.log('Closing email modal');
    document.getElementById('emailModal').style.display = 'none';
    document.body.style.overflow = 'auto';
    document.getElementById('emailForm').reset();
}

// Handle form submission to send email using EmailJS
document.addEventListener('DOMContentLoaded', function() {
    const emailForm = document.getElementById('emailForm');
    if (!emailForm) {
        console.error('ERROR: Email form not found');
        return;
    }
    
    emailForm.addEventListener('submit', function(e) {
        console.log("=== FORM SUBMISSION STARTED ===");
        e.preventDefault(); // Prevent the form from submitting in the usual way
        
        const formData = new FormData(this);
        const data = Object.fromEntries(formData); // Convert FormData to a regular object
        
        // Debug: Check if guide email is present
        console.log('Raw form data:', formData);
        console.log('Converted form data:', data);
        console.log('Guide email from hidden field:', data.guideEmail);
        console.log('Guide email type:', typeof data.guideEmail);
        console.log('Guide email length:', data.guideEmail ? data.guideEmail.length : 'undefined');
        
        // Also check the actual input field value
        const guideEmailInput = document.getElementById('guideEmail');
        console.log('Direct input field value:', guideEmailInput ? guideEmailInput.value : 'field not found');
        
        // Validate that guide email exists
        if (!data.guideEmail || data.guideEmail.trim() === '') {
            console.error('ERROR: Guide email is missing from form data');
            alert('Error: Guide email is missing. Please try again or contact the administrator.');
            return;
        }
        
        // Prepare the email data object for EmailJS
        const emailData = {
            to_email: data.guideEmail.trim(), // Recipient email (guide's email) - trim whitespace
            to_name: data.guideName,   // Recipient name (guide's name)
            guide_name: data.guideName,
            visitor_name: data.visitorName,
            visitor_email: data.visitorEmail,
            from_name: data.visitorName,
            from_email: data.visitorEmail,
            visit_date: data.visitDate,
            group_size: data.groupSize,
            message: data.message,
            reply_to: data.visitorEmail
        };
        
        console.log("=== EMAIL DATA PREPARED ===");
        console.log("Complete email data object:", emailData);
        console.log("to_email field specifically:", `"${emailData.to_email}"`);
        console.log("to_email length:", emailData.to_email.length);

        // Show loading state
        const submitButton = this.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        submitButton.disabled = true;

        console.log("Calling EmailJS send...");
        // Use EmailJS to send the email with updated syntax
        emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, emailData)
            .then((response) => {
                console.log("=== EMAIL SENT SUCCESSFULLY ===");
                console.log("EmailJS response:", response);
                alert('Email sent successfully!');
                window.closeEmailModal(); // Close the modal after email is sent
            })
            .catch((error) => {
                console.error("=== EMAIL SEND ERROR ===");
                console.error("Error object:", error);
                console.error("Error status:", error.status);
                console.error("Error text:", error.text);
                console.error("Error message:", error.message);
                console.error("Full error object:", JSON.stringify(error, null, 2));
                alert(`Failed to send email. Please try again later.\nError: ${error.text || error.message || 'Unknown error'}`);
            })
            .finally(() => {
                // Reset button state
                submitButton.innerHTML = originalText;
                submitButton.disabled = false;
            });
    });
});

// Show Guide Info Function
window.showGuideInfo = function(guideName) {
    alert(`${guideName} is a licensed wildlife guide at Semenggoh Wildlife Centre with extensive knowledge of local flora and fauna. Contact them for personalized tours and educational experiences.`);
}

// Set minimum date for visitDate input
document.addEventListener('DOMContentLoaded', function() {
    const visitDateInput = document.getElementById('visitDate');
    if (visitDateInput) {
        visitDateInput.min = new Date().toISOString().split('T')[0];
    }
});