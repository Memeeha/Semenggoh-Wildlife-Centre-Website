import cv2
from ultralytics import YOLO
import firebase_admin
from firebase_admin import credentials, db
import threading
import time

# --- Firebase setup ---
# Load Firebase service account key from JSON file
cred = credentials.Certificate('firebase_key.json')
# Initialize Firebase app with your Realtime Database URL
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://test-9d9ca-default-rtdb.asia-southeast1.firebasedatabase.app/'
})

# --- Global variables ---
# Dictionary to store sensor data received from Firebase
sensor_data = {
    "temperature": None,
    "humidity": None
}

def listen_firebase():
    """
    Listen for real-time updates from Firebase on the '/sensors' node.
    Updates the global sensor_data dictionary whenever data changes.
    """
    def listener(event):
        path = event.path  # Path of the changed data relative to '/sensors', e.g. '/temperature'
        data = event.data  # New value at that path
        print(f"Firebase event path: {path}, data: {data}")  # Debug print to monitor changes
        
        if path == "/temperature":
            sensor_data["temperature"] = data
        elif path == "/humidity":
            sensor_data["humidity"] = data
        elif path == "/":  # Initial full data snapshot received when listener starts
            # event.data is a dictionary with all keys/values under '/sensors'
            if isinstance(data, dict):
                sensor_data["temperature"] = data.get("temperature", None)
                sensor_data["humidity"] = data.get("humidity", None)

    # Reference to the '/sensors' node in Firebase Realtime Database
    sensors_ref = db.reference("/sensors")
    # Start listening for any changes under '/sensors'
    sensors_ref.listen(listener)

# Start the Firebase listener function in a separate daemon thread
threading.Thread(target=listen_firebase, daemon=True).start()

# --- YOLO model setup ---
# Load your custom YOLO model from file
model = YOLO('yolo11n.pt')

# Start capturing video from the default camera (usually webcam at index 0)
cap = cv2.VideoCapture(0)

while True:
    # Grab a single frame from the camera
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    # Run YOLO detection on the current frame
    results = model(frame)

    # Draw bounding boxes and other annotations on the frame
    annotated_frame = results[0].plot()

    # Sometimes annotated frame has 4 channels (BGRA), convert to 3 channels (BGR) to avoid display issues
    if annotated_frame.shape[2] == 4:
        annotated_frame = cv2.cvtColor(annotated_frame, cv2.COLOR_BGRA2BGR)

    # --- Prepare text to show temperature and humidity ---
    temp_text = "Temp: N/A"
    humid_text = "Humidity: N/A"
    if sensor_data["temperature"] is not None:
        try:
            # Format temperature to 1 decimal place with unit Celsius
            temp_text = f"Temp: {float(sensor_data['temperature']):.1f} C"
        except Exception as e:
            print("Error formatting temperature:", e)
    if sensor_data["humidity"] is not None:
        try:
            # Format humidity to 1 decimal place with unit percent
            humid_text = f"Humidity: {float(sensor_data['humidity']):.1f} %"
        except Exception as e:
            print("Error formatting humidity:", e)

    # --- Draw background rectangle for text (top-right corner) ---
    box_width, box_height = 180, 60
    top_right_x = annotated_frame.shape[1] - box_width - 10  # 10px padding from right edge
    top_right_y = 10  # 10px padding from top edge

    # Draw filled dark grey rectangle as background for sensor text
    cv2.rectangle(annotated_frame,
                  (top_right_x, top_right_y),
                  (top_right_x + box_width, top_right_y + box_height),
                  (50, 50, 50),  # RGB color (dark grey)
                  thickness=-1)  # Filled rectangle

    # --- Put the temperature and humidity text on the rectangle ---
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    color = (255, 255, 255)  # White color text
    thickness = 2

    # Position texts inside the rectangle with some padding
    cv2.putText(annotated_frame, temp_text, (top_right_x + 10, top_right_y + 25), font, font_scale, color, thickness)
    cv2.putText(annotated_frame, humid_text, (top_right_x + 10, top_right_y + 50), font, font_scale, color, thickness)

    # --- Display the final annotated frame ---
    cv2.imshow('YOLO11 Detection with Sensor Data', annotated_frame)

    # Press 'q' key to quit the video loop and close window
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera resource and close any OpenCV windows
cap.release()
cv2.destroyAllWindows()
